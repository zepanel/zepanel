-- Olay işleyicilerinin gerçek çalıştırma günlüğü (olayla tetiklenen ve elle yapılan çalıştırmalar). İşleyiciyle birlikte silinir.
CREATE TABLE tools_event_handler_runs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  handler_id  uuid NOT NULL REFERENCES tools_event_handlers (id) ON DELETE CASCADE,
  event       text NOT NULL,
  trigger     text NOT NULL CHECK (trigger IN ('event', 'manual')),
  started_at  timestamptz NOT NULL DEFAULT now(),
  duration_ms integer NOT NULL DEFAULT 0 CHECK (duration_ms >= 0),
  exit_code   integer NOT NULL,
  status      text NOT NULL CHECK (status IN ('success', 'failed')),
  output      text NOT NULL DEFAULT ''
);
CREATE INDEX tools_event_handler_runs_handler_idx ON tools_event_handler_runs (handler_id, started_at DESC);
