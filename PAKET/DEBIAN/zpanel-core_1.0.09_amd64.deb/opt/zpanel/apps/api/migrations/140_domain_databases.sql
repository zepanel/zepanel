-- Alan adı veritabanları (databases sekmesi). Kayıtlar gerçek; fiziksel oluşturma Go ajanına bağlıdır.
CREATE TABLE domain_databases (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id   uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name        text NOT NULL,
  engine      text NOT NULL CHECK (engine IN ('mariadb', 'mysql', 'pgsql')),
  charset     text NOT NULL,
  size_bytes  bigint NOT NULL DEFAULT 0 CHECK (size_bytes >= 0),
  table_count integer NOT NULL DEFAULT 0 CHECK (table_count >= 0),
  created_at  timestamptz NOT NULL DEFAULT now(),
  checked_at  timestamptz NOT NULL DEFAULT now()
);
-- database names are unique on the server, so across all domains
CREATE UNIQUE INDEX domain_databases_name_uq ON domain_databases (name);
CREATE INDEX domain_databases_domain_idx ON domain_databases (domain_id);

CREATE TABLE domain_database_users (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id    uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name         text NOT NULL,
  access       text NOT NULL DEFAULT 'local' CHECK (access IN ('local', 'remote')),
  -- AES-256-GCM (src/secrets.ts); never returned by the API
  password_enc text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX domain_database_users_name_uq ON domain_database_users (name);
CREATE INDEX domain_database_users_domain_idx ON domain_database_users (domain_id);

CREATE TABLE domain_database_grants (
  database_id uuid NOT NULL REFERENCES domain_databases (id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES domain_database_users (id) ON DELETE CASCADE,
  privileges  text[] NOT NULL,
  PRIMARY KEY (database_id, user_id),
  CHECK (cardinality(privileges) > 0)
);
CREATE INDEX domain_database_grants_user_idx ON domain_database_grants (user_id);

CREATE TABLE domain_database_ips (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  ip         text NOT NULL,
  note       text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, ip)
);

CREATE TABLE domain_database_backups (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_id uuid NOT NULL REFERENCES domain_databases (id) ON DELETE CASCADE,
  kind        text NOT NULL CHECK (kind IN ('manual', 'auto')),
  size_bytes  bigint NOT NULL DEFAULT 0 CHECK (size_bytes >= 0),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX domain_database_backups_db_idx ON domain_database_backups (database_id, created_at DESC);
