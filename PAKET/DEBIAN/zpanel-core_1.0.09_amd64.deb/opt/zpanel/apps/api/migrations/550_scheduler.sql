-- Server-wide scheduled tasks (Araçlar > Planlanmış görevler) and the default index.html of new domains.
-- The panel only stores them; the agent runs them (no agent: running a task answers 503 agent_unavailable).
CREATE TABLE scheduler_tasks (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type         text NOT NULL CHECK (type IN ('cmd', 'php', 'url')),
  command      text NOT NULL CHECK (char_length(command) BETWEEN 1 AND 300),
  php_version  text NOT NULL DEFAULT '8.3',
  run_user     text NOT NULL CHECK (run_user IN ('root', 'admin', 'site_user')),
  schedule     text NOT NULL CHECK (char_length(schedule) BETWEEN 9 AND 100),
  notify       text NOT NULL DEFAULT 'error' CHECK (notify IN ('error', 'always', 'never')),
  notify_email text NOT NULL DEFAULT '' CHECK (char_length(notify_email) <= 120),
  enabled      boolean NOT NULL DEFAULT true,
  created_by   uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
-- the same command with the same schedule and user can only be defined once
CREATE UNIQUE INDEX scheduler_tasks_uq ON scheduler_tasks (type, command, run_user, schedule);

-- Run history; it goes away with its task.
CREATE TABLE scheduler_runs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id     uuid NOT NULL REFERENCES scheduler_tasks (id) ON DELETE CASCADE,
  started_at  timestamptz NOT NULL DEFAULT now(),
  duration_ms integer NOT NULL DEFAULT 0 CHECK (duration_ms >= 0),
  exit_code   integer NOT NULL,
  status      text NOT NULL CHECK (status IN ('success', 'failed')),
  trigger     text NOT NULL CHECK (trigger IN ('manual', 'scheduled')),
  output      text NOT NULL DEFAULT ''
);
CREATE INDEX scheduler_runs_task_idx ON scheduler_runs (task_id, started_at DESC);
CREATE INDEX scheduler_runs_time_idx ON scheduler_runs (started_at DESC);

-- A single row; no row means the built-in default template.
CREATE TABLE scheduler_vhost_template (
  id         smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  content    text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 65536),
  updated_by uuid REFERENCES users (id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
