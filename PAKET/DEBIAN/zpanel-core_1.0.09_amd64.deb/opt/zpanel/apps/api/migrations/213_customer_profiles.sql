-- Müşteri ek bilgileri (tür, vergi no, adres, dil, servis planı, özel sınırlar, faturalama). users tablosu değişmez.
CREATE TABLE customer_profiles (
  user_id        uuid PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
  type           text NOT NULL DEFAULT 'individual' CHECK (type IN ('individual', 'corporate')),
  tax_no         text NOT NULL DEFAULT '',
  address        text NOT NULL DEFAULT '',
  city           text NOT NULL DEFAULT '',
  lang           text NOT NULL DEFAULT 'tr' CHECK (lang IN ('tr', 'en')),
  plan_id        text REFERENCES service_plans (id) ON DELETE SET NULL,
  -- NULL: servis planının sınırları geçerli; dolu: bu müşteriye özel sınırlar (-1 = sınırsız)
  custom_limits  jsonb,
  email_verified boolean NOT NULL DEFAULT false,
  note           text NOT NULL DEFAULT '',
  billing        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_profiles_plan_idx ON customer_profiles (plan_id) WHERE plan_id IS NOT NULL;
