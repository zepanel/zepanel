-- Security tab: IP rules, password protected directories, per-domain protection settings, scan findings.
CREATE TABLE security_ip_rules (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  address    text NOT NULL CHECK (char_length(address) <= 49),
  list_type  text NOT NULL CHECK (list_type IN ('deny', 'allow')),
  note       text NOT NULL DEFAULT '' CHECK (char_length(note) <= 80),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, address)
);

CREATE TABLE security_dirs (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  path       text NOT NULL CHECK (char_length(path) <= 120),
  realm      text NOT NULL CHECK (char_length(realm) BETWEEN 3 AND 60),
  enabled    boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- exact comparison: paths are case sensitive on the server, and lower() is locale dependent in PostgreSQL (I becomes dotless i under Turkish rules)
CREATE UNIQUE INDEX security_dirs_path_uq ON security_dirs (domain_id, path);

-- The password is stored encrypted (src/secrets.ts) so the agent can write the .htpasswd entry; it is never returned.
CREATE TABLE security_dir_users (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dir_id          uuid NOT NULL REFERENCES security_dirs (id) ON DELETE CASCADE,
  username        text NOT NULL CHECK (username ~ '^[a-z0-9._-]{3,32}$'),
  password_secret text NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (dir_id, username)
);

CREATE TABLE security_settings (
  domain_id  uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  hotlink    jsonb,
  waf        jsonb,
  brute      jsonb,
  headers    jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE security_scans (
  domain_id    uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  last_scan_at timestamptz NOT NULL
);

CREATE TABLE security_findings (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  code      text NOT NULL CHECK (code ~ '^[a-z0-9_]{1,40}$'),
  severity  text NOT NULL CHECK (severity IN ('high', 'medium', 'low')),
  location  text NOT NULL CHECK (char_length(location) <= 300),
  status    text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'fixed')),
  found_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, code)
);
