-- Third domain status: "disabled" (Devre Dışı) next to active and suspended.
ALTER TABLE domains DROP CONSTRAINT domains_status_check;
ALTER TABLE domains ADD CONSTRAINT domains_status_check CHECK (status IN ('active', 'suspended', 'disabled'));
