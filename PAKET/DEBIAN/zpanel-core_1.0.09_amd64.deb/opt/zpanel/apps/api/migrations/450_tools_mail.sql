-- Mail server tools (Tools & Settings > Mail > Server settings / Outgoing mail / Smarthost).
-- Single-row settings tables (id = 1) start with defaults; updated_at stays NULL until an administrator saves them.
-- The relay password is never stored.
CREATE TABLE tools_mail_settings (
  id              smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled         boolean NOT NULL DEFAULT true,
  hostname        text NOT NULL DEFAULT '' CHECK (char_length(hostname) <= 253),
  banner          text NOT NULL DEFAULT 'zPanel Posta Sunucusu' CHECK (char_length(banner) <= 80),
  max_size_mb     integer NOT NULL DEFAULT 50 CHECK (max_size_mb BETWEEN 1 AND 512),
  quota_mb        integer NOT NULL DEFAULT 1024 CHECK (quota_mb BETWEEN 100 AND 102400),
  max_recipients  integer NOT NULL DEFAULT 100 CHECK (max_recipients BETWEEN 1 AND 1000),
  max_connections integer NOT NULL DEFAULT 100 CHECK (max_connections BETWEEN 1 AND 500),
  queue_days      integer NOT NULL DEFAULT 5 CHECK (queue_days BETWEEN 1 AND 30),
  relay           text NOT NULL DEFAULT 'auth' CHECK (relay IN ('auth', 'pop', 'closed')),
  tls             text NOT NULL DEFAULT 'required' CHECK (tls IN ('required', 'opportunistic', 'none')),
  updated_at      timestamptz
);
INSERT INTO tools_mail_settings (id) VALUES (1);

CREATE TABLE tools_mail_outgoing (
  id          smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  domain_hour integer NOT NULL DEFAULT 100 CHECK (domain_hour BETWEEN 1 AND 100000),
  box_hour    integer NOT NULL DEFAULT 50 CHECK (box_hour BETWEEN 1 AND 10000),
  box_day     integer NOT NULL DEFAULT 500 CHECK (box_day BETWEEN 1 AND 100000),
  max_rcpt    integer NOT NULL DEFAULT 50 CHECK (max_rcpt BETWEEN 1 AND 500),
  action      text NOT NULL DEFAULT 'defer' CHECK (action IN ('defer', 'reject')),
  notify      boolean NOT NULL DEFAULT true,
  suspend     boolean NOT NULL DEFAULT true,
  updated_at  timestamptz
);
INSERT INTO tools_mail_outgoing (id) VALUES (1);

CREATE TABLE tools_mail_senders (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address    text NOT NULL UNIQUE CHECK (char_length(address) <= 120),
  per_hour   integer NOT NULL CHECK (per_hour BETWEEN 1 AND 10000),
  per_day    integer NOT NULL CHECK (per_day BETWEEN 1 AND 100000),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tools_mail_blacklist (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address    text NOT NULL UNIQUE CHECK (char_length(address) <= 120),
  reason     text NOT NULL DEFAULT '' CHECK (char_length(reason) <= 80),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tools_mail_smarthost (
  id               smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled          boolean NOT NULL DEFAULT false,
  host             text NOT NULL DEFAULT '' CHECK (char_length(host) <= 253),
  port             integer NOT NULL DEFAULT 587 CHECK (port BETWEEN 1 AND 65535),
  security         text NOT NULL DEFAULT 'starttls' CHECK (security IN ('starttls', 'ssl', 'none')),
  auth             boolean NOT NULL DEFAULT true,
  username         text NOT NULL DEFAULT '' CHECK (char_length(username) <= 120),
  last_test_ok     boolean,
  last_test_target text NOT NULL DEFAULT '',
  last_test_at     timestamptz,
  updated_at       timestamptz
);
INSERT INTO tools_mail_smarthost (id) VALUES (1);
