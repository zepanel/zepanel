-- lower() follows the database locale; under Turkish rules 'I' becomes a dotless i, so "Admin" and "admin"
-- would stop colliding. The unique index folds case with the "C" collation (ASCII only, locale independent).
DROP INDEX IF EXISTS users_username_lower_uq;
CREATE UNIQUE INDEX users_username_lower_uq ON users (lower(username COLLATE "C"));
