-- SSL/TLS certificates and HTTPS settings per domain (tab "ssl").
-- The private key is stored encrypted (src/secrets.ts, AES-256-GCM) and never leaves the API.
CREATE TABLE ssl_certificates (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id          uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  common_name        text NOT NULL,
  sans               text[] NOT NULL DEFAULT '{}',
  type               text NOT NULL CHECK (type IN ('le', 'up', 'self')),
  issuer             text NOT NULL,
  key_type           text NOT NULL,
  serial             text NOT NULL,
  fingerprint        text NOT NULL,
  issued_at          timestamptz NOT NULL,
  expires_at         timestamptz NOT NULL,
  auto_renew         boolean NOT NULL DEFAULT false,
  certificate_pem    text NOT NULL,
  chain_pem          text,
  chain_names        text[] NOT NULL DEFAULT '{}',
  chain_ok           boolean NOT NULL DEFAULT false,
  private_key_secret text NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ssl_certificates_fingerprint_uq ON ssl_certificates (domain_id, fingerprint);
CREATE INDEX ssl_certificates_domain_idx ON ssl_certificates (domain_id, expires_at);

CREATE TABLE ssl_domain_settings (
  domain_id               uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  active_certificate_id   uuid REFERENCES ssl_certificates (id) ON DELETE SET NULL,
  redirect_https          boolean NOT NULL DEFAULT false,
  hsts                    boolean NOT NULL DEFAULT false,
  hsts_max_age            integer NOT NULL DEFAULT 31536000 CHECK (hsts_max_age IN (15552000, 31536000, 63072000)),
  hsts_include_subdomains boolean NOT NULL DEFAULT false,
  hsts_preload            boolean NOT NULL DEFAULT false,
  tls_min                 text NOT NULL DEFAULT '1.2' CHECK (tls_min IN ('1.0', '1.2', '1.3')),
  ocsp_stapling           boolean NOT NULL DEFAULT true,
  contact_email           text,
  -- false while the web server has not received this state (agent unavailable)
  applied                 boolean NOT NULL DEFAULT false,
  updated_at              timestamptz NOT NULL DEFAULT now()
);
