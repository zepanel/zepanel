-- Sunucu yedeği: otomatik çalıştırma durumu (çift çalıştırmayı önleyen son çalışma damgası) ve müşteri veritabanları kapsamı.
ALTER TABLE tools_backup_schedule ADD COLUMN last_run_at timestamptz;

-- yeni içerik türü "customerDb" (müşteri veritabanları): zamanlama kapsamı ve geri yükleme kayıtları onu da kabul eder
ALTER TABLE tools_backup_schedule DROP CONSTRAINT tools_backup_schedule_scope_check;
ALTER TABLE tools_backup_schedule ADD CONSTRAINT tools_backup_schedule_scope_check
  CHECK (scope <@ ARRAY['config', 'sites', 'db', 'customerDb', 'mail']::text[] AND cardinality(scope) > 0);
ALTER TABLE tools_backup_restores DROP CONSTRAINT tools_backup_restores_scopes_check;
ALTER TABLE tools_backup_restores ADD CONSTRAINT tools_backup_restores_scopes_check
  CHECK (scopes <@ ARRAY['config', 'sites', 'db', 'customerDb', 'mail']::text[] AND cardinality(scopes) > 0);
