-- Plan quotas beyond service_plans columns (D4/D5): backup quota, PHP memory/time ceilings. -1 = unlimited.
-- Bandwidth quota is service_plans.traffic_gb (D5). Kept in a side table so service_plans is not altered.
CREATE TABLE service_plan_quotas (
  plan_id          text PRIMARY KEY REFERENCES service_plans (id) ON DELETE CASCADE,
  backup_gb        integer NOT NULL DEFAULT 20 CHECK (backup_gb = -1 OR backup_gb BETWEEN 1 AND 1000000),
  php_memory_mb    integer NOT NULL DEFAULT 256 CHECK (php_memory_mb = -1 OR php_memory_mb BETWEEN 32 AND 65536),
  php_max_exec_s   integer NOT NULL DEFAULT 60 CHECK (php_max_exec_s = -1 OR php_max_exec_s BETWEEN 1 AND 3600)
);

INSERT INTO service_plan_quotas (plan_id, backup_gb, php_memory_mb, php_max_exec_s) VALUES
  ('baslangic', 5, 128, 30),
  ('standart', 20, 256, 60),
  ('profesyonel', 50, 512, 120),
  ('kurumsal', 200, 1024, 300),
  ('bayi', 500, 1024, 300),
  ('sinirsiz', -1, -1, -1);

-- A plan without a row here (created later) uses the column defaults when read.
