-- WordPress, Node.js ve Laravel Toolkit panelle birlikte varsayılan yüklü gelir (Yüklü Uzantılar listesinde görünür, yan menüde bunlara bağlıdır).
-- Yönetici isterse kaldırır; göç yalnız bir kez çalıştığı için kaldırılan uzantı kendiliğinden geri gelmez.
INSERT INTO ext_installed (ext_id, version) VALUES
  ('ozel-wordpress-toolkit', '1.0.0'),
  ('node-toolkit', '1.0.0'),
  ('laravel-toolkit', '1.0.0')
ON CONFLICT (ext_id) DO NOTHING;
