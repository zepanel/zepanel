-- zpanel-login jail: no fail2ban filter and no panel login-failure log are installed anywhere, so the jail cannot work.
-- It is off by default (an administrator can still turn it on once a filter exists).
UPDATE fail2ban_jails SET enabled = false, updated_at = now() WHERE name = 'zpanel-login' AND enabled;
