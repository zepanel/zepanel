-- Database servers (Tools & Settings > Databases): the servers the panel creates customer databases on, plus the hosting preferences.
-- The administrator password is stored encrypted (src/secrets.ts) and never returned. Counts, size and version are
-- filled in by the server agent's connection test; until then they stay 0 / unknown.
CREATE TABLE db_servers (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name           text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  host           text NOT NULL CHECK (char_length(host) BETWEEN 1 AND 253),
  port           integer NOT NULL CHECK (port BETWEEN 1 AND 65535),
  engine         text NOT NULL CHECK (engine IN ('mysql', 'mariadb', 'postgresql')),
  version        text NOT NULL DEFAULT '-',
  admin_user     text NOT NULL CHECK (char_length(admin_user) BETWEEN 1 AND 64),
  admin_password text NOT NULL,
  db_count       integer NOT NULL DEFAULT 0 CHECK (db_count >= 0),
  size_gb        numeric(10, 2) NOT NULL DEFAULT 0 CHECK (size_gb >= 0),
  status         text NOT NULL DEFAULT 'online' CHECK (status IN ('online', 'offline')),
  is_default     boolean NOT NULL DEFAULT false,
  checked_at     timestamptz,
  created_by     uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX db_servers_endpoint_uq ON db_servers (lower(host COLLATE "C"), port);
CREATE UNIQUE INDEX db_servers_default_uq ON db_servers (is_default) WHERE is_default;

-- Single row (id = 1); no row means the defaults apply and nothing was saved yet.
CREATE TABLE db_hosting_prefs (
  id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  pma_url      text NOT NULL CHECK (char_length(pma_url) <= 500),
  coll_name    text NOT NULL,
  user_quota   integer NOT NULL CHECK (user_quota BETWEEN 1 AND 1000),
  local_access boolean NOT NULL,
  any_ip       boolean NOT NULL,
  updated_by   uuid REFERENCES users (id) ON DELETE SET NULL,
  saved_at     timestamptz NOT NULL DEFAULT now()
);
