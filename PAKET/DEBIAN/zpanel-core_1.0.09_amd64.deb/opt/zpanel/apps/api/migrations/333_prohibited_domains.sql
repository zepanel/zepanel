-- Prohibited domain name patterns (tools/security). "*.example.com" blocks every subdomain, "example.com" only that name.
CREATE TABLE prohibited_domains (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pattern    text NOT NULL CHECK (char_length(pattern) BETWEEN 3 AND 253 AND pattern = lower(pattern)),
  reason     text NOT NULL DEFAULT '' CHECK (char_length(reason) <= 120),
  blocked    integer NOT NULL DEFAULT 0 CHECK (blocked >= 0),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX prohibited_domains_pattern_uq ON prohibited_domains (pattern);
