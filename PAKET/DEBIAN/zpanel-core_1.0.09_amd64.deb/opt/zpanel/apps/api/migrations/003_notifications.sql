CREATE TABLE notifications (
  id         bigserial PRIMARY KEY,
  user_id    uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  level      text NOT NULL DEFAULT 'info' CHECK (level IN ('info', 'ok', 'warn', 'bad')),
  title      text NOT NULL,
  body       text NOT NULL DEFAULT '',
  href       text,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at    timestamptz
);

CREATE INDEX notifications_user_created_idx ON notifications (user_id, created_at DESC);
CREATE INDEX notifications_user_unread_idx ON notifications (user_id) WHERE read_at IS NULL;
