-- Customer profile fields, reseller ownership and soft delete for users.
ALTER TABLE users
  ADD COLUMN display_name text,
  ADD COLUMN phone        text,
  ADD COLUMN company      text,
  ADD COLUMN reseller_id  uuid REFERENCES users (id);

ALTER TABLE users DROP CONSTRAINT users_status_check;
ALTER TABLE users ADD CONSTRAINT users_status_check CHECK (status IN ('active', 'suspended', 'deleted'));

CREATE INDEX users_reseller_idx ON users (reseller_id) WHERE reseller_id IS NOT NULL;
CREATE INDEX users_role_status_idx ON users (role, status);
