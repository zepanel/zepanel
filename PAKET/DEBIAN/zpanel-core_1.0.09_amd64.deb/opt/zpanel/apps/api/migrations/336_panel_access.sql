-- Panel access restriction (tools/security): IPv4 allow list for the administration interface.
-- addr is "*" (everyone), "a.b.c.d" (one host) or "a.b.c.d/n" (network, n 0..31), normalised by the application.
CREATE TABLE panel_access_rules (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  addr        text NOT NULL CHECK (char_length(addr) BETWEEN 1 AND 43),
  kind        text NOT NULL CHECK (kind IN ('all', 'host', 'net')),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 80),
  created_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX panel_access_rules_addr_uq ON panel_access_rules (addr);
