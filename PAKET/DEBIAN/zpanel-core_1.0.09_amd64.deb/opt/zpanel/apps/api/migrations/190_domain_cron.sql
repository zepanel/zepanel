-- Scheduled tasks of a domain. The command is only stored here; the agent runs it (allow-listed).
CREATE TABLE cron_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id     uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name          text NOT NULL,
  type          text NOT NULL CHECK (type IN ('cmd', 'php', 'url')),
  command       text NOT NULL,
  php_version   text NOT NULL DEFAULT '8.3',
  schedule      text NOT NULL,
  enabled       boolean NOT NULL DEFAULT true,
  notify_enabled boolean NOT NULL DEFAULT false,
  notify_email  text NOT NULL DEFAULT '',
  notify_when   text NOT NULL DEFAULT 'fail' CHECK (notify_when IN ('fail', 'always')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX cron_tasks_name_uq ON cron_tasks (domain_id, lower(name));

-- Run history survives task deletion (task_id becomes NULL, the name and command line are kept).
CREATE TABLE cron_runs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id   uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  task_id     uuid REFERENCES cron_tasks (id) ON DELETE SET NULL,
  task_name   text NOT NULL,
  command_line text NOT NULL,
  started_at  timestamptz NOT NULL DEFAULT now(),
  duration_ms integer NOT NULL DEFAULT 0 CHECK (duration_ms >= 0),
  exit_code   integer NOT NULL,
  output      text NOT NULL DEFAULT ''
);
CREATE INDEX cron_runs_domain_idx ON cron_runs (domain_id, started_at DESC);
CREATE INDEX cron_runs_task_idx ON cron_runs (task_id, started_at DESC);
