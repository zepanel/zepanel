-- Olay işleyicileri (tools/utilities/event-handlers, G14). Kayıtlar panelde saklanır; komutların çalıştırılması sunucu ajanının işidir.
CREATE TABLE tools_event_handlers (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event       text NOT NULL CHECK (event IN ('domain_created', 'domain_deleted', 'mailbox_created', 'customer_created')),
  priority    text NOT NULL DEFAULT 'normal' CHECK (priority IN ('high', 'normal', 'low')),
  run_user    text NOT NULL CHECK (run_user IN ('root', 'admin', 'site_user')),
  command     text NOT NULL CHECK (char_length(command) BETWEEN 2 AND 300 AND left(command, 1) = '/'),
  run_count   integer NOT NULL DEFAULT 0 CHECK (run_count >= 0),
  last_run_at timestamptz,
  created_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX tools_event_handlers_uq ON tools_event_handlers (event, run_user, command);
