-- Redirect rules of a primary domain plus its two global switches (force HTTPS, www preference).
CREATE TABLE domain_redirect_settings (
  domain_id   uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  force_https boolean NOT NULL DEFAULT false,
  www_mode    text NOT NULL DEFAULT 'none' CHECK (www_mode IN ('none', 'www', 'nowww')),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE domain_redirects (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq        bigint GENERATED ALWAYS AS IDENTITY,
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  kind       text NOT NULL CHECK (kind IN ('path', 'host')),
  source     text NOT NULL CHECK (char_length(source) BETWEEN 1 AND 300),
  target     text NOT NULL CHECK (char_length(target) BETWEEN 1 AND 2000),
  code       smallint NOT NULL CHECK (code IN (301, 302)),
  wildcard   boolean NOT NULL DEFAULT false,
  active     boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX domain_redirects_domain_idx ON domain_redirects (domain_id, seq);
