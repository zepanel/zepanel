-- zBackup (panel çekirdeği, ücretsiz): Google Cloud OAuth ayarı, üye başına Google hesabı bağlantısı ve arka plan yedek işleri.
-- Dosyaları sıkıştıran, parçalayan, MD5 ile doğrulayan ve yükleyen taraf ajandır; burada yalnızca ayar, kimlik ve ilerleme kayıtları tutulur.

-- Tek satır: müşterinin (panel sahibinin) kendi Google Cloud OAuth istemcisi. Gizli anahtar yalnızca şifreli saklanır (secrets.ts), API yanıtlarında asla dönmez.
CREATE TABLE zbackup_oauth (
  id         smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  client_id  text NOT NULL DEFAULT '' CHECK (char_length(client_id) <= 255),
  -- Google Cloud'daki "yetkili yönlendirme URI" ile birebir aynı olmalı (panel adresi + /v1/zbackup/google/callback).
  redirect_uri text NOT NULL DEFAULT '' CHECK (char_length(redirect_uri) <= 500),
  secret_enc text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO zbackup_oauth (id) VALUES (1);

-- Üye başına Google hesabı: yönetici, satıcı ve müşteri kendi hesabıyla giriş yapıp izin verir. Yenileme anahtarı şifreli saklanır.
CREATE TABLE zbackup_google_accounts (
  user_id      uuid PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
  refresh_enc  text NOT NULL,
  email        text NOT NULL DEFAULT '' CHECK (char_length(email) <= 255),
  connected_at timestamptz NOT NULL DEFAULT now()
);

-- Arka plan işleri: arayüz işi başlatıp hemen döner; ilerleme bu satırdan okunur, sayfadan ayrılmak işi durdurmaz.
CREATE TABLE zbackup_jobs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  state        text NOT NULL DEFAULT 'running' CHECK (state IN ('running', 'done', 'failed')),
  -- compressing: sıkıştırılıyor, uploading: parçalı yedekleme, databases: veritabanları, verifying: MD5 doğrulaması, done
  phase        text NOT NULL DEFAULT 'compressing' CHECK (phase IN ('compressing', 'uploading', 'databases', 'verifying', 'done')),
  percent      smallint CHECK (percent IS NULL OR percent BETWEEN 0 AND 100),
  parts_done   integer NOT NULL DEFAULT 0 CHECK (parts_done >= 0),
  parts_total  integer CHECK (parts_total IS NULL OR parts_total >= 1),
  bytes        bigint NOT NULL DEFAULT 0 CHECK (bytes >= 0),
  error        text NOT NULL DEFAULT '' CHECK (char_length(error) <= 300),
  started_at   timestamptz NOT NULL DEFAULT now(),
  finished_at  timestamptz
);
CREATE INDEX zbackup_jobs_user_idx ON zbackup_jobs (user_id, started_at DESC);
-- Bir üyenin aynı anda tek çalışan işi olabilir.
CREATE UNIQUE INDEX zbackup_jobs_one_running_idx ON zbackup_jobs (user_id) WHERE state = 'running';
