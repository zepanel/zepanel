-- Monitoring Toolkit: server-wide threshold rule (single row). Uninstalling the extension keeps this row.
-- A threshold is a whole percent (1-100) or NULL (no rule for that metric).
CREATE TABLE monitoring_rules (
  id         smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled    boolean NOT NULL DEFAULT false,
  cpu_pct    smallint CHECK (cpu_pct BETWEEN 1 AND 100),
  mem_pct    smallint CHECK (mem_pct BETWEEN 1 AND 100),
  disk_pct   smallint CHECK (disk_pct BETWEEN 1 AND 100),
  notify     boolean NOT NULL DEFAULT true,
  updated_by uuid REFERENCES users (id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO monitoring_rules (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
