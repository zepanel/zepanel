-- Hizmet planlarının sahibi: satıcı kendi planlarını yönetir, yönetici hepsini görür. NULL = yöneticiye/sisteme ait (mevcut planlar).
ALTER TABLE service_plans ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES users(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS service_plans_owner_idx ON service_plans (owner_id);
