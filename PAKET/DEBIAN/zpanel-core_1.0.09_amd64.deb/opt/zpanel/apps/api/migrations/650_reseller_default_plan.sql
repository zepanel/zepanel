-- Satıcı planı: tek varsayılan plan "default_reseller" (adı limitsiz_reseller, tüm sınırlar ve izinler sınırsız)
ALTER TABLE reseller_plans DROP CONSTRAINT IF EXISTS reseller_plans_id_check;
ALTER TABLE reseller_plans ADD CONSTRAINT reseller_plans_id_check CHECK (id ~ '^[a-z0-9_]+$');

INSERT INTO reseller_plans (id, name, description, limits, perms, sort_order) VALUES
  ('default_reseller', 'limitsiz_reseller', 'Varsayılan satıcı planı: tüm kaynaklar ve yetkiler sınırsız',
   '{"disk":-1,"traffic":-1,"customers":-1,"domains":-1,"mail":-1,"db":-1}', '{customers,plans,dns,ssh,ssl,backup,wp,suspend}', 0)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE reseller_profiles ALTER COLUMN plan_id SET DEFAULT 'default_reseller';
UPDATE reseller_profiles SET plan_id = 'default_reseller' WHERE plan_id = 'sinirsiz';

-- eski örnek planlar ve ara plan: kullanan satıcı yoksa kaldırılır
DELETE FROM reseller_plans
 WHERE id IN ('sinirsiz', 'bronze', 'silver', 'gold', 'platinum')
   AND NOT EXISTS (SELECT 1 FROM reseller_profiles p WHERE p.plan_id = reseller_plans.id);
