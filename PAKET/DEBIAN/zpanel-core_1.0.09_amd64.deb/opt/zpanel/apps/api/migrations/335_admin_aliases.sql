-- Additional administrator accounts (tools/security). The login itself is a normal users row with role 'admin';
-- this table keeps the contact name and the scope. An admin user without a row here is the server owner (scope 'super').
CREATE TABLE admin_aliases (
  user_id      uuid PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
  contact_name text NOT NULL CHECK (char_length(contact_name) BETWEEN 2 AND 60),
  scope        text NOT NULL CHECK (scope IN ('super', 'server', 'helper', 'ro')),
  created_by   uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
