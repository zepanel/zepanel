-- Same as 007: fold the task name with the "C" collation so the unique index does not depend on the database locale.
DROP INDEX IF EXISTS cron_tasks_name_uq;
CREATE UNIQUE INDEX cron_tasks_name_uq ON cron_tasks (domain_id, lower(name COLLATE "C"));
