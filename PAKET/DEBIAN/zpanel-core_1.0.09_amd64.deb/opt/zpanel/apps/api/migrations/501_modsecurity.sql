-- Web application firewall (tools/security/modsecurity): protection settings and rule exceptions.
-- The blocked-request log and the counters come from the agent (phase 3).
CREATE TABLE modsecurity_settings (
  id          smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  mode        text NOT NULL DEFAULT 'block' CHECK (mode IN ('off', 'detect', 'block')),
  ruleset     text NOT NULL DEFAULT 'crs4' CHECK (ruleset IN ('crs4', 'crs3', 'basic')),
  auto_update boolean NOT NULL DEFAULT true,
  audit       text NOT NULL DEFAULT 'relevant' CHECK (audit IN ('relevant', 'all', 'off')),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
INSERT INTO modsecurity_settings (id) VALUES (1);

CREATE TABLE modsecurity_exceptions (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id    text NOT NULL CHECK (rule_id ~ '^[0-9]{6}$'),
  scope      text NOT NULL CHECK (char_length(scope) BETWEEN 1 AND 120 AND scope LIKE '/%'),
  note       text NOT NULL DEFAULT '' CHECK (char_length(note) <= 100),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX modsecurity_exceptions_uq ON modsecurity_exceptions (rule_id, scope);
