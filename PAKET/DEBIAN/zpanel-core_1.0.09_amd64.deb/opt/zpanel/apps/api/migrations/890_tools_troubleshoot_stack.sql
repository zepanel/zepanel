-- Onarım kiti: "stack" (hizmet yapısı) kategorisi. Kategori kısıtları genişletilir; mevcut satırlar değişmez.
ALTER TABLE tools_troubleshoot_scan_state DROP CONSTRAINT IF EXISTS tools_troubleshoot_scan_state_category_check;
ALTER TABLE tools_troubleshoot_scan_state ADD CONSTRAINT tools_troubleshoot_scan_state_category_check CHECK (category IN ('web', 'perm', 'db', 'dns', 'ssl', 'mail', 'stack'));
ALTER TABLE tools_troubleshoot_findings DROP CONSTRAINT IF EXISTS tools_troubleshoot_findings_category_check;
ALTER TABLE tools_troubleshoot_findings ADD CONSTRAINT tools_troubleshoot_findings_category_check CHECK (category IN ('web', 'perm', 'db', 'dns', 'ssl', 'mail', 'stack'));
