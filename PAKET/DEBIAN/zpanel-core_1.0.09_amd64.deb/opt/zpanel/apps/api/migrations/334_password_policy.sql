-- Panel-wide password policy (Tools & Settings > Security > Security policy). Single row (id = 1).
CREATE TABLE password_policy (
  id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  level        text NOT NULL DEFAULT 'very_strong' CHECK (level IN ('very_strong', 'strong', 'medium', 'weak', 'custom')),
  min_len      integer NOT NULL DEFAULT 10 CHECK (min_len BETWEEN 6 AND 32),
  upper        boolean NOT NULL DEFAULT true,
  lower        boolean NOT NULL DEFAULT true,
  digit        boolean NOT NULL DEFAULT true,
  special      boolean NOT NULL DEFAULT true,
  no_user      boolean NOT NULL DEFAULT true,
  max_age_days integer NOT NULL DEFAULT 90 CHECK (max_age_days BETWEEN 0 AND 365),
  twofa        boolean NOT NULL DEFAULT true,
  twofa_all    boolean NOT NULL DEFAULT false CHECK (twofa OR NOT twofa_all),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

INSERT INTO password_policy (id) VALUES (1);
