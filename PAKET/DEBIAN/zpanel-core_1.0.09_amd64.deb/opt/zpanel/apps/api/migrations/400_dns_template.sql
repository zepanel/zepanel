-- Global DNS template (tools/general): the records and SOA values every new zone starts with.
-- Record names are relative to the zone ("@" = zone itself); values may hold the placeholders <domain>, <ip> and <ipv6>.
-- The singleton row of dns_template_soa also marks the template as seeded, so an emptied template stays empty.
CREATE TABLE dns_template_soa (
  singleton    boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  primary_ns   text NOT NULL CHECK (char_length(primary_ns) BETWEEN 3 AND 254),
  email        text NOT NULL CHECK (char_length(email) BETWEEN 3 AND 254),
  ttl_s        integer NOT NULL CHECK (ttl_s BETWEEN 300 AND 2147483647),
  refresh_s    integer NOT NULL CHECK (refresh_s BETWEEN 1200 AND 2147483647),
  retry_s      integer NOT NULL CHECK (retry_s BETWEEN 300 AND 2147483647),
  expire_s     integer NOT NULL CHECK (expire_s BETWEEN 86400 AND 2147483647),
  minimum_s    integer NOT NULL CHECK (minimum_s BETWEEN 60 AND 2147483647),
  dated_serial boolean NOT NULL DEFAULT false,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE dns_template_records (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq        bigint GENERATED ALWAYS AS IDENTITY,
  name       text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 253),
  type       text NOT NULL CHECK (type IN ('A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV')),
  value      text NOT NULL CHECK (char_length(value) BETWEEN 1 AND 4096),
  ttl        integer NOT NULL CHECK (ttl BETWEEN 60 AND 604800),
  prio       integer CHECK (prio BETWEEN 0 AND 65535),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX dns_template_records_seq_idx ON dns_template_records (seq);
