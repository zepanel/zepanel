-- Dovecot parola özeti (SCRAM-SHA-256): panelin Argon2id özeti Dovecot'ta doğrulanamadığından hesap parolası ayrıca bu biçimde saklanır.
-- Bu sütunu olmayan (eski) hesaplar parola yeniden belirlenene kadar posta girişi yapamaz.
ALTER TABLE mail_accounts ADD COLUMN IF NOT EXISTS dovecot_hash text;
