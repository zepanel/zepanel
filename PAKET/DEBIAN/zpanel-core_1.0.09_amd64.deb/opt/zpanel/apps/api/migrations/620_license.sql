-- Lisans etkinleştirme kaydı (tek satır): kurulum sihirbazının /etc/zpanel/license.json dosyasının karşılığı.
-- Lisans anahtarının kendisi ASLA saklanmaz; yalnızca son 4 hanesi tutulur.
CREATE TABLE license_activation (
  id              smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  installation_id text NOT NULL CHECK (char_length(installation_id) BETWEEN 1 AND 64),
  fingerprint     text NOT NULL CHECK (char_length(fingerprint) BETWEEN 1 AND 128),
  key_last4       text NOT NULL CHECK (char_length(key_last4) = 4),
  activated_at    timestamptz NOT NULL DEFAULT now(),
  api             text NOT NULL CHECK (char_length(api) BETWEEN 1 AND 255)
);
