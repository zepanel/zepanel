-- Sunucu geneli yedekleme (tools/utilities/backup-*, G12): yedek kayıtları, geri yükleme geçmişi, zamanlama ve uzak depo ayarı.
-- Arşiv dosyalarını yazan/geri yükleyen taraf ajandır (Faz 3); burada yalnızca kayıtlar ve ayarlar tutulur.
CREATE TABLE tools_backup_backups (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind        text NOT NULL DEFAULT 'manual' CHECK (kind IN ('auto', 'manual')),
  status      text NOT NULL DEFAULT 'run' CHECK (status IN ('ok', 'fail', 'run')),
  size_bytes  bigint NOT NULL DEFAULT 0 CHECK (size_bytes >= 0),
  -- içerik türüne göre bayt dağılımı: {"config":n,"sites":n,"db":n,"mail":n}; tamamlanmamış yedekte boş
  parts       jsonb NOT NULL DEFAULT '{}'::jsonb,
  files_count integer NOT NULL DEFAULT 0 CHECK (files_count >= 0),
  duration_s  integer NOT NULL DEFAULT 0 CHECK (duration_s >= 0),
  note        text NOT NULL DEFAULT '' CHECK (char_length(note) <= 120),
  remote      boolean NOT NULL DEFAULT false,
  error       text NOT NULL DEFAULT '' CHECK (char_length(error) <= 300),
  archive     text NOT NULL DEFAULT '',
  sha256      text NOT NULL DEFAULT '' CHECK (sha256 = '' OR sha256 ~ '^[0-9a-f]{64}$'),
  created_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tools_backup_backups_created_idx ON tools_backup_backups (created_at DESC);

CREATE TABLE tools_backup_restores (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  backup_id  uuid NOT NULL REFERENCES tools_backup_backups (id) ON DELETE CASCADE,
  scopes     text[] NOT NULL CHECK (scopes <@ ARRAY['config', 'sites', 'db', 'mail']::text[] AND cardinality(scopes) > 0),
  conflict   text NOT NULL CHECK (conflict IN ('keep', 'replace')),
  email      text NOT NULL DEFAULT '',
  status     text NOT NULL CHECK (status IN ('ok', 'fail')),
  actor      text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tools_backup_restores_backup_idx ON tools_backup_restores (backup_id, created_at DESC);

-- Tek satırlık zamanlama. Yerel/uzak kota sunucu ayarıdır (D4: alan adı kotası hizmet planından, sunucu geneli kota burada).
CREATE TABLE tools_backup_schedule (
  id              smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled         boolean NOT NULL DEFAULT false,
  period          text NOT NULL DEFAULT 'daily' CHECK (period IN ('daily', 'weekly', 'monthly')),
  run_time        text NOT NULL DEFAULT '03:00' CHECK (run_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  weekday         smallint NOT NULL DEFAULT 1 CHECK (weekday BETWEEN 0 AND 6),
  monthday        smallint NOT NULL DEFAULT 1 CHECK (monthday BETWEEN 1 AND 28),
  keep            smallint NOT NULL DEFAULT 7 CHECK (keep BETWEEN 1 AND 60),
  scope           text[] NOT NULL DEFAULT ARRAY['config', 'sites', 'db', 'mail']::text[] CHECK (scope <@ ARRAY['config', 'sites', 'db', 'mail']::text[] AND cardinality(scope) > 0),
  target          text NOT NULL DEFAULT 'local' CHECK (target IN ('local', 'both')),
  local_quota_gb  integer NOT NULL DEFAULT 250 CHECK (local_quota_gb > 0),
  remote_quota_gb integer NOT NULL DEFAULT 500 CHECK (remote_quota_gb > 0),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
INSERT INTO tools_backup_schedule (id) VALUES (1);

-- Uzak depo: erişim anahtarı / gizli anahtar / parola yalnızca şifreli saklanır (secrets.ts), API yanıtlarında asla dönmez.
CREATE TABLE tools_backup_remote (
  id         smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled    boolean NOT NULL DEFAULT false,
  kind       text NOT NULL DEFAULT 's3' CHECK (kind IN ('s3', 'sftp', 'ftp', 'gdrive')),
  endpoint   text NOT NULL DEFAULT '' CHECK (char_length(endpoint) <= 255),
  bucket     text NOT NULL DEFAULT '' CHECK (char_length(bucket) <= 255),
  region     text NOT NULL DEFAULT '' CHECK (char_length(region) <= 30),
  account    text NOT NULL DEFAULT '' CHECK (char_length(account) <= 255),
  gpath      text NOT NULL DEFAULT '' CHECK (char_length(gpath) <= 255),
  tls        boolean NOT NULL DEFAULT true,
  encrypt    boolean NOT NULL DEFAULT true,
  access_enc text,
  secret_enc text,
  tested_at  timestamptz,
  tested_ok  boolean,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO tools_backup_remote (id) VALUES (1);
