-- Uzantı ayarlarına "Menüde göster" (aktif/pasif) seçeneği: kenar çubuğundaki Uzantılar menüsünde uzantının sayfa bağlantısı gösterilsin mi.
-- Pasif yapmak uzantıyı devre dışı bırakmaz, yalnız menü bağlantısını gizler.
-- Mevcut kurulu uzantılar görünür kalır (sütun eklenirken varsayılan true); bundan sonra kurulan TÜM uzantılar menüde PASİF gelir (sahip kararı 2026-11-07).
ALTER TABLE ext_installed ADD COLUMN IF NOT EXISTS show_menu boolean NOT NULL DEFAULT true;
ALTER TABLE ext_installed ALTER COLUMN show_menu SET DEFAULT false;
