-- Lisans etkinleştirildiği anda doğrulanan sunucu IP'si.
-- Kayıt başka bir sunucuya kopyalanırsa veya IP değişirse lisans yeniden doğrulanana kadar panel açılmaz.
ALTER TABLE license_activation
  ADD COLUMN server_ip text NULL
  CHECK (server_ip IS NULL OR char_length(server_ip) BETWEEN 3 AND 45);
