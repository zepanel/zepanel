-- Sunucu IP adresi havuzu (tools/utilities/ip-addresses, P44). Adresler kanonik biçimde saklanır (IPv6 sıkıştırılmış, küçük harf).
CREATE TABLE ip_addresses (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address    text NOT NULL CHECK (char_length(address) BETWEEN 2 AND 45 AND address = lower(address)),
  version    smallint NOT NULL CHECK (version IN (4, 6)),
  prefix     smallint NOT NULL CHECK (prefix BETWEEN 0 AND 128),
  iface      text NOT NULL CHECK (iface IN ('eth0', 'eth1')),
  type       text NOT NULL DEFAULT 'shared' CHECK (type IN ('shared', 'exclusive')),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ip_addresses_address_uq ON ip_addresses (address);

-- Bir alan adının (sitenin) kullandığı adres; alan adı başına en fazla bir adres. Kullanımdaki adres silinemez.
CREATE TABLE ip_address_sites (
  domain_id  uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  ip_id      uuid NOT NULL REFERENCES ip_addresses (id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ip_address_sites_ip_idx ON ip_address_sites (ip_id);
