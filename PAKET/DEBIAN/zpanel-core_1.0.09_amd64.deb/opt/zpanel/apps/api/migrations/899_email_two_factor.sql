-- E-posta ile iki aşamalı doğrulama: açık olduğunda girişte kullanıcının e-postasına 6 haneli tek kullanımlık kod gider.
-- email_two_factor_at dolu = e-posta 2FA açık. Google Authenticator (two_factor_secret) ile birlikte açık olamaz.
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS email_two_factor_at timestamptz;

-- Gönderilen kodlar: yalnız özeti tutulur, 10 dakika geçerlidir, 5 yanlış denemede kullanılamaz.
-- purpose: 'enable' = ayarı açarken gönderilen kod, 'login' = girişte gönderilen kod.
CREATE TABLE IF NOT EXISTS email_two_factor_codes (
  user_id    uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  purpose    text NOT NULL CHECK (purpose IN ('enable', 'login')),
  code_hash  bytea NOT NULL,
  expires_at timestamptz NOT NULL,
  tries      smallint NOT NULL DEFAULT 0,
  sent_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, purpose)
);
