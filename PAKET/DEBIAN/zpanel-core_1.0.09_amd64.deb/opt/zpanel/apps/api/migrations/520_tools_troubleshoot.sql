-- Sorun giderme (tools/troubleshooting: advisor, repair-kit, config-troubleshooter, G10).
-- Önerilerde yalnızca yoksayma/uygulama kararı saklanır; öneriler canlı denetimlerden üretilir.
CREATE TABLE tools_troubleshoot_advice (
  rec_id     text PRIMARY KEY CHECK (char_length(rec_id) BETWEEN 1 AND 64),
  state      text NOT NULL CHECK (state IN ('ignored', 'applied')),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Onarım kiti: kategori başına son tarama sonucu.
CREATE TABLE tools_troubleshoot_scan_state (
  category   text PRIMARY KEY CHECK (category IN ('web', 'perm', 'db', 'dns', 'ssl', 'mail')),
  status     text NOT NULL CHECK (status IN ('clean', 'issues', 'unavailable')),
  scanned_at timestamptz NOT NULL DEFAULT now()
);

-- Bulgular: kod bulgunun kimliğidir; metinler arayüzde koddan ve params değerlerinden üretilir.
CREATE TABLE tools_troubleshoot_findings (
  code      text PRIMARY KEY CHECK (char_length(code) BETWEEN 1 AND 64),
  category  text NOT NULL CHECK (category IN ('web', 'perm', 'db', 'dns', 'ssl', 'mail')),
  severity  text NOT NULL CHECK (severity IN ('danger', 'warning', 'info')),
  params    jsonb NOT NULL DEFAULT '{}'::jsonb,
  state     text NOT NULL DEFAULT 'open' CHECK (state IN ('open', 'fixed')),
  found_at  timestamptz NOT NULL DEFAULT now(),
  fixed_at  timestamptz
);
CREATE INDEX tools_troubleshoot_findings_category_idx ON tools_troubleshoot_findings (category);

-- Tarama günlüğü (son 500 satır tutulur).
CREATE TABLE tools_troubleshoot_log (
  id     bigserial PRIMARY KEY,
  at     timestamptz NOT NULL DEFAULT now(),
  level  text NOT NULL DEFAULT 'info' CHECK (level IN ('info', 'warn', 'err', 'dim')),
  code   text NOT NULL CHECK (char_length(code) BETWEEN 1 AND 64),
  params jsonb NOT NULL DEFAULT '{}'::jsonb
);

-- Tek satır: toplam onarım sayısı ve son tarama/test zamanları.
CREATE TABLE tools_troubleshoot_meta (
  id             smallint PRIMARY KEY CHECK (id = 1),
  fixed_total    integer NOT NULL DEFAULT 0 CHECK (fixed_total >= 0),
  last_scan_at   timestamptz,
  last_config_at timestamptz
);

-- Yapılandırma denetimi: adım başına son sonuç (testi ajan çalıştırır).
CREATE TABLE tools_troubleshoot_config_results (
  step_id   text PRIMARY KEY CHECK (char_length(step_id) BETWEEN 1 AND 64),
  engine    text NOT NULL CHECK (engine IN ('nginx', 'ols')),
  version   text NOT NULL DEFAULT '' CHECK (char_length(version) <= 32),
  result   text NOT NULL CHECK (result IN ('ok', 'warn', 'bad')),
  lines     jsonb NOT NULL DEFAULT '[]'::jsonb,
  tested_at timestamptz NOT NULL DEFAULT now()
);
