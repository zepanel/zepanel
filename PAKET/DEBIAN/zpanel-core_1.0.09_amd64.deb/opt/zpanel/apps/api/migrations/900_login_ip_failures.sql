-- Giriş denemelerinde IP bazlı kademeli kilit: her yanlış parola/kod IP'nin sayacını artırır; eşikler aşılınca o IP'den giriş
-- süreli engellenir (5 yanlış = 3 dk, 10 = 30 dk, 20 = 3 sa, 30 = 6 sa, 50 ve üstü = 24 sa). Hesap kilitlenmez: biri başkasının
-- hesabını yanlış parolayla kilitleyemez. Sayaç, son yanlıştan 24 saat sonra kendiliğinden sıfırlanır.
CREATE TABLE IF NOT EXISTS login_ip_failures (
  ip              inet PRIMARY KEY,
  failures        integer NOT NULL DEFAULT 0,
  locked_until    timestamptz,
  last_failure_at timestamptz NOT NULL DEFAULT now()
);
