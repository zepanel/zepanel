-- Panel updates (Tools & Settings > Panel > Updates / Update settings).
-- Settings: single row (id = 1); updated_at stays NULL until an administrator saves them. History: one row per update check or installation.
CREATE TABLE tools_update_settings (
  id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  channel      text NOT NULL DEFAULT 'stable' CHECK (channel IN ('stable', 'preview')),
  auto_check   boolean NOT NULL DEFAULT true,
  interval     text NOT NULL DEFAULT 'daily' CHECK (interval IN ('daily', 'weekly')),
  security     boolean NOT NULL DEFAULT true,
  os_packages  boolean NOT NULL DEFAULT true,
  day          text NOT NULL DEFAULT 'sun' CHECK (day IN ('daily', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')),
  time         text NOT NULL DEFAULT '03:00' CHECK (time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  notify_panel boolean NOT NULL DEFAULT true,
  notify_mail  boolean NOT NULL DEFAULT false,
  email        text NOT NULL DEFAULT '' CHECK (char_length(email) <= 254),
  updated_at   timestamptz
);

INSERT INTO tools_update_settings (id) VALUES (1);

CREATE TABLE tools_update_history (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  at          timestamptz NOT NULL DEFAULT now(),
  kind        text NOT NULL CHECK (kind IN ('check', 'update', 'install')),
  version     text NOT NULL CHECK (char_length(version) <= 64),
  channel     text NOT NULL CHECK (channel IN ('stable', 'preview')),
  duration_ms integer NOT NULL DEFAULT 0 CHECK (duration_ms >= 0),
  result      text NOT NULL CHECK (result IN ('success', 'current', 'failed'))
);

CREATE INDEX tools_update_history_at_idx ON tools_update_history (at DESC);
