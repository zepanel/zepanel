-- Araçlar > Yardımcı programlar: toplu e-posta kuyruğu/geçmişi (tools/utilities/mass-mail) ve SSH terminali bağlantı ayarı (ssh-terminal).
-- Gönderim ve terminal oturumu sunucu ajanının işidir (503 agent_unavailable); burada yalnızca yönetimsel veri saklanır.
CREATE TABLE mass_mail_queue (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject    text NOT NULL CHECK (char_length(subject) BETWEEN 1 AND 150),
  message    text NOT NULL CHECK (char_length(message) BETWEEN 10 AND 5000),
  audience   text NOT NULL CHECK (audience IN ('all', 'resellers', 'active')),
  recipients integer NOT NULL CHECK (recipients >= 0),
  status     text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at    timestamptz
);
CREATE INDEX mass_mail_queue_created_idx ON mass_mail_queue (created_at DESC, id);

-- Tek satır: terminalin bağlanacağı sunucu bilgisi. Boş ana bilgisayar adı = bu sunucunun adı.
CREATE TABLE ssh_terminal_settings (
  singleton  boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  host       text NOT NULL DEFAULT '' CHECK (char_length(host) <= 253),
  port       integer NOT NULL DEFAULT 22 CHECK (port BETWEEN 1 AND 65535),
  username   text NOT NULL DEFAULT 'root' CHECK (username ~ '^[a-z_][a-z0-9_-]{0,31}$'),
  updated_by uuid REFERENCES users (id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO ssh_terminal_settings (singleton) VALUES (true);
