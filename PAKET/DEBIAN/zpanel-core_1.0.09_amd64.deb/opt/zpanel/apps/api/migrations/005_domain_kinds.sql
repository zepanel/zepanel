-- Subdomains and alias domains live in the same table as primary domains.
-- parent_id: the parent domain of a subdomain, or the target domain of an alias.
ALTER TABLE domains
  ADD COLUMN kind      text NOT NULL DEFAULT 'domain' CHECK (kind IN ('domain', 'subdomain', 'alias')),
  ADD COLUMN parent_id uuid REFERENCES domains (id),
  ADD COLUMN settings  jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD CONSTRAINT domains_parent_rule CHECK ((kind = 'domain') = (parent_id IS NULL));

CREATE INDEX domains_parent_idx ON domains (parent_id) WHERE parent_id IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX domains_kind_idx ON domains (kind) WHERE deleted_at IS NULL;
