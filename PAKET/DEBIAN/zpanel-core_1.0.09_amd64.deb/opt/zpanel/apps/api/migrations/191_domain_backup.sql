-- Backup records of a domain. Creating, restoring and downloading files is done by the agent;
-- these tables hold what the panel manages: the records, the schedule and the remote-storage setting.
CREATE TABLE backup_backups (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id   uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  type        text NOT NULL CHECK (type IN ('full', 'files', 'db')),
  size_bytes  bigint NOT NULL DEFAULT 0 CHECK (size_bytes >= 0),
  locations   text[] NOT NULL DEFAULT '{local}',
  status      text NOT NULL DEFAULT 'run' CHECK (status IN ('ok', 'fail', 'run')),
  auto        boolean NOT NULL DEFAULT false,
  note        text NOT NULL DEFAULT '',
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX backup_backups_domain_idx ON backup_backups (domain_id, created_at DESC);

CREATE TABLE backup_schedules (
  domain_id  uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  enabled    boolean NOT NULL DEFAULT false,
  freq       text NOT NULL DEFAULT 'daily' CHECK (freq IN ('daily', 'weekly', 'monthly')),
  day        integer NOT NULL DEFAULT 1 CHECK (day BETWEEN 1 AND 28),
  time       text NOT NULL DEFAULT '03:00' CHECK (time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  scope      text NOT NULL DEFAULT 'full' CHECK (scope IN ('full', 'files', 'db')),
  keep       integer NOT NULL DEFAULT 7 CHECK (keep BETWEEN 1 AND 60),
  remote     boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- kind/host/path are provisioned with the agent; the panel only switches the storage on or off.
CREATE TABLE backup_remote (
  domain_id    uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  enabled      boolean NOT NULL DEFAULT false,
  kind         text,
  host         text,
  path         text,
  last_sync_at timestamptz,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE backup_restores (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id   uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  backup_id   uuid REFERENCES backup_backups (id) ON DELETE SET NULL,
  backup_type text NOT NULL CHECK (backup_type IN ('full', 'files', 'db')),
  backup_at   timestamptz NOT NULL,
  scope       text NOT NULL CHECK (scope IN ('all', 'files', 'db')),
  actor       text NOT NULL,
  status      text NOT NULL CHECK (status IN ('ok', 'fail')),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX backup_restores_domain_idx ON backup_restores (domain_id, created_at DESC);
