-- Alan adı <-> abonelik köprüsü. Bir abonelik (subscriptions.domain_id = ana alan adı) birden çok ek alan adı taşıyabilir;
-- ek alan adı sayısı servis planının `domains` sınırıyla (abonelik alan adı dahil) denetlenir. Bir alan adı en çok bir aboneliğe bağlanır.
CREATE TABLE domain_subscriptions (
  domain_id       uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  subscription_id uuid NOT NULL REFERENCES subscriptions (domain_id) ON DELETE CASCADE,
  created_at      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT domain_subscriptions_not_self CHECK (domain_id <> subscription_id)
);
CREATE INDEX domain_subscriptions_sub_idx ON domain_subscriptions (subscription_id);
