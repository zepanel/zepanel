-- Hizmet planları (Servis Planları sayfası). Sınır -1 = sınırsız. Plan kimliği ad'dan türetilen sabit bir metindir.
CREATE TABLE service_plans (
  id          text PRIMARY KEY CHECK (id ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text NOT NULL CHECK (char_length(name) BETWEEN 3 AND 40),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 80),
  disk_gb     integer NOT NULL CHECK (disk_gb = -1 OR disk_gb BETWEEN 1 AND 1000000),
  traffic_gb  integer NOT NULL CHECK (traffic_gb = -1 OR traffic_gb BETWEEN 1 AND 1000000),
  domains     integer NOT NULL CHECK (domains = -1 OR domains BETWEEN 1 AND 1000000),
  mail        integer NOT NULL CHECK (mail = -1 OR mail BETWEEN 1 AND 1000000),
  db          integer NOT NULL CHECK (db = -1 OR db BETWEEN 1 AND 1000000),
  perms       text[] NOT NULL DEFAULT '{}',
  php         text NOT NULL CHECK (php IN ('8.2', '8.3', '8.4', '8.5')),
  sort_order  serial,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

INSERT INTO service_plans (id, name, description, disk_gb, traffic_gb, domains, mail, db, perms, php) VALUES
  ('baslangic',   'Başlangıç',   'Tek site için giriş paketi',            5,   50,   1,   5,    1,   '{php,backup}', '8.3'),
  ('standart',    'Standart',    'Küçük işletme siteleri',                20,  200,  3,   25,   5,   '{php,cron,backup}', '8.3'),
  ('profesyonel', 'Profesyonel', 'Geliştirici ve ajans projeleri',        50,  500,  10,  100,  20,  '{php,ssh,cron,backup,wp}', '8.3'),
  ('kurumsal',    'Kurumsal',    'Yüksek trafikli kurumsal siteler',      200, 2000, 50,  500,  100, '{php,ssh,cron,backup,wp,node}', '8.4'),
  ('bayi',        'Bayi',        'Yeniden satış yapan hesaplar',          500, 5000, 200, 2000, 500, '{php,ssh,cron,backup,wp,node,laravel}', '8.4'),
  ('sinirsiz',    'Sınırsız',    'Kaynak sınırı olmayan özel paket',      -1,  -1,   -1,  -1,   -1,  '{php,ssh,cron,backup,wp,node,laravel}', '8.4');
