-- phpMyAdmin'i dışarıya açma anahtarı ve IP kısıtı (Panel Ayarları). Varsayılan AÇIK ve kısıtsız: mevcut otomatik giriş bozulmaz.
ALTER TABLE db_hosting_prefs
  ADD COLUMN pma_open        boolean NOT NULL DEFAULT true,
  ADD COLUMN pma_allowed_ips text[]  NOT NULL DEFAULT '{}' CHECK (cardinality(pma_allowed_ips) <= 50);
