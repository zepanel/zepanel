-- Extensions (C7). The catalog itself is static (modules/extensions/catalog.json); the database keeps
-- what is installed, the per-extension update settings, uploaded packages and the history.
CREATE TABLE ext_custom (
  id         text PRIMARY KEY CHECK (id ~ '^ozel-[a-z0-9-]{1,60}$'),
  name       text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  vendor     text NOT NULL CHECK (char_length(vendor) BETWEEN 1 AND 80),
  version    text NOT NULL CHECK (version ~ '^\d+(\.\d+){1,3}$'),
  size_bytes bigint NOT NULL CHECK (size_bytes > 0),
  added_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ext_installed (
  ext_id       text PRIMARY KEY,
  version      text NOT NULL CHECK (version ~ '^\d+(\.\d+){1,3}$'),
  enabled      boolean NOT NULL DEFAULT true,
  auto_update  boolean NOT NULL DEFAULT true,
  channel      text NOT NULL DEFAULT 'stable' CHECK (channel IN ('stable', 'preview')),
  notify_mail  boolean NOT NULL DEFAULT true,
  keep_days    integer NOT NULL DEFAULT 30 CHECK (keep_days BETWEEN 1 AND 365),
  installed_at timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ext_history (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  kind         text NOT NULL CHECK (kind IN ('install', 'remove', 'update', 'enable', 'disable')),
  ext_id       text NOT NULL,
  ext_name     text NOT NULL DEFAULT '',
  from_version text NOT NULL DEFAULT '',
  to_version   text NOT NULL DEFAULT '',
  actor_id     uuid REFERENCES users (id) ON DELETE SET NULL,
  at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ext_history_at_idx ON ext_history (at DESC, id DESC);

-- Single row: global update behaviour and the time of the last update check.
CREATE TABLE ext_settings (
  id            boolean PRIMARY KEY DEFAULT true CHECK (id),
  auto_security boolean NOT NULL DEFAULT true,
  last_check    timestamptz
);
INSERT INTO ext_settings (id) VALUES (true);
