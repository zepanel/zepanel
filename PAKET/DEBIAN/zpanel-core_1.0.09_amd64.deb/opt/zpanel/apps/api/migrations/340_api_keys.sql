-- REST API keys (tools/services). Only a SHA-256 hash of the key is stored; the secret is shown once at creation.
CREATE TABLE api_keys (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id           uuid REFERENCES users (id) ON DELETE CASCADE,
  label              text NOT NULL CHECK (char_length(label) BETWEEN 3 AND 80),
  description        text NOT NULL DEFAULT '' CHECK (char_length(description) <= 240),
  key_prefix         text NOT NULL CHECK (char_length(key_prefix) = 11),
  key_hash           text NOT NULL,
  scope              text NOT NULL CHECK (scope IN ('read', 'write')),
  expiry_days        integer NOT NULL CHECK (expiry_days IN (30, 90, 180, 365)),
  expires_at         timestamptz NOT NULL,
  allowed_ips        text[] NOT NULL DEFAULT '{}' CHECK (cardinality(allowed_ips) <= 20),
  rate_limit_per_min integer NOT NULL DEFAULT 600 CHECK (rate_limit_per_min BETWEEN 1 AND 100000),
  last_used_at       timestamptz,
  last_used_ip       inet,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX api_keys_hash_uq ON api_keys (key_hash);
CREATE INDEX api_keys_prefix_idx ON api_keys (key_prefix);

-- Hourly request counters per key (24 hour and 7 day usage). Revoking a key deletes its row and counters.
CREATE TABLE api_key_usage (
  key_id   uuid NOT NULL REFERENCES api_keys (id) ON DELETE CASCADE,
  bucket   timestamptz NOT NULL,
  requests integer NOT NULL DEFAULT 0,
  PRIMARY KEY (key_id, bucket)
);
