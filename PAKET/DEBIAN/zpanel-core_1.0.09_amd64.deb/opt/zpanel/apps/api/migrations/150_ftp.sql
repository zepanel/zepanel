-- FTP accounts of a domain. Passwords are stored encrypted (AES-256-GCM, src/secrets.ts) so the server
-- agent can apply them to the FTP service; they are never returned by the API.
CREATE TABLE ftp_accounts (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id      uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  username       text NOT NULL,
  home           text NOT NULL,
  -- 0 = unlimited
  quota_mb       integer NOT NULL DEFAULT 0 CHECK (quota_mb >= 0),
  -- measured by the agent; 0 until the agent reports
  used_mb        integer NOT NULL DEFAULT 0 CHECK (used_mb >= 0),
  status         text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
  read_only      boolean NOT NULL DEFAULT false,
  password_secret text NOT NULL,
  last_login_at  timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- FTP user names are server-wide
CREATE UNIQUE INDEX ftp_accounts_username_uq ON ftp_accounts (username);
CREATE INDEX ftp_accounts_domain_idx ON ftp_accounts (domain_id);
