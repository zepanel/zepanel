-- System package updates (Tools & Settings > Services > Updates / Update settings).
-- Settings: single row (id = 1); updated_at stays NULL until an administrator saves them. last_check_at is set by a manual check.
-- History: one row per package installed through the panel.
CREATE TABLE tools_os_update_settings (
  id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  auto_check   boolean NOT NULL DEFAULT true,
  freq         text NOT NULL DEFAULT 'daily' CHECK (freq IN ('daily', 'weekly', 'monthly')),
  check_time   text NOT NULL DEFAULT '03:00' CHECK (check_time ~ '^(([01][0-9]|2[0-3]):[0-5][0-9])?$'),
  auto_install boolean NOT NULL DEFAULT true,
  scope        text NOT NULL DEFAULT 'security' CHECK (scope IN ('security', 'all')),
  restart      boolean NOT NULL DEFAULT true,
  win_day      text NOT NULL DEFAULT 'sun' CHECK (win_day IN ('all', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')),
  win_start    text NOT NULL DEFAULT '02:00' CHECK (win_start ~ '^(([01][0-9]|2[0-3]):[0-5][0-9])?$'),
  win_end      text NOT NULL DEFAULT '05:00' CHECK (win_end ~ '^(([01][0-9]|2[0-3]):[0-5][0-9])?$'),
  channel      text NOT NULL DEFAULT 'stable' CHECK (channel IN ('stable', 'beta')),
  email        text NOT NULL DEFAULT '' CHECK (char_length(email) <= 254),
  n_available  boolean NOT NULL DEFAULT true,
  n_security   boolean NOT NULL DEFAULT true,
  n_installed  boolean NOT NULL DEFAULT true,
  n_failed     boolean NOT NULL DEFAULT true,
  n_restart    boolean NOT NULL DEFAULT false,
  proxy_host   text NOT NULL DEFAULT '' CHECK (char_length(proxy_host) <= 253),
  proxy_port   text NOT NULL DEFAULT '' CHECK (proxy_port ~ '^[0-9]{0,5}$'),
  last_check_at timestamptz,
  updated_at   timestamptz
);

INSERT INTO tools_os_update_settings (id) VALUES (1);

CREATE TABLE tools_os_update_history (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  at        timestamptz NOT NULL DEFAULT now(),
  name      text NOT NULL CHECK (char_length(name) <= 128),
  version   text NOT NULL CHECK (char_length(version) <= 64),
  result    text NOT NULL CHECK (result IN ('success', 'failed')),
  seconds   integer NOT NULL DEFAULT 0 CHECK (seconds >= 0)
);

CREATE INDEX tools_os_update_history_at_idx ON tools_os_update_history (at DESC);
