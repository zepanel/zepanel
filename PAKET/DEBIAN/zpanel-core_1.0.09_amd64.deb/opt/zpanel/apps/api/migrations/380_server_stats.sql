-- Server statistics (C6). The panel samples the operating system itself (CPU, memory, disk, load);
-- disk I/O, network and per-domain figures come from the agent and are not stored here.
CREATE TABLE server_stat_samples (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  at            timestamptz NOT NULL DEFAULT now(),
  cpu_pct       real NOT NULL CHECK (cpu_pct BETWEEN 0 AND 100),
  mem_used_mb   integer NOT NULL CHECK (mem_used_mb >= 0),
  mem_cache_mb  integer NOT NULL CHECK (mem_cache_mb >= 0),
  mem_total_mb  integer NOT NULL CHECK (mem_total_mb > 0),
  disk_used_gb  real NOT NULL CHECK (disk_used_gb >= 0),
  disk_total_gb real NOT NULL CHECK (disk_total_gb >= 0),
  load1         real NOT NULL CHECK (load1 >= 0),
  load5         real NOT NULL CHECK (load5 >= 0),
  load15        real NOT NULL CHECK (load15 >= 0)
);
CREATE INDEX server_stat_samples_at_idx ON server_stat_samples (at);
