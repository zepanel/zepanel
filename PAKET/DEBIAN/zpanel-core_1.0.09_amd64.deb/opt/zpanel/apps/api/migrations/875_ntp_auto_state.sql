-- Otomatik NTP eşitleme durumu (worker): tek satır; son talep zamanı. Aynı aralıkta iki worker/tick eşitlemeyi iki kez başlatmasın
-- (atomik talep: UPDATE ... WHERE claimed_at <= $sınır), eşitleme sonucu ayrıca utilities.ntp-history geçmişine yazılır.
CREATE TABLE tools_ntp_auto (
  singleton  boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  claimed_at timestamptz
);
