-- Uzak lisans API'sinin etkinleştirmede verdiği kurulum belirteci (Bearer). Yalnızca ZPANEL_SECRET_KEY ile
-- şifreli (secrets.ts, v1:...) saklanır; yanıtlara, günlüklere ve denetim kayıtlarına asla yazılmaz.
-- Lisans devre dışı bırakılırken uzak API'ye bu belirteçle bildirilir. Eski kayıtlarda null olabilir.
ALTER TABLE license_activation ADD COLUMN installation_token_enc text NULL;
