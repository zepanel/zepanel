-- Panel sertifikaları (tools/security/ssl, ssl-detail, ssl-upload). Özel anahtar secrets.ts ile şifreli saklanır ve API yanıtlarında asla yer almaz.
CREATE TABLE panel_certificates (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name               text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 80),
  common_name        text NOT NULL,
  sans               text[] NOT NULL DEFAULT '{}',
  issuer             text NOT NULL,
  issuer_org         text NOT NULL DEFAULT '',
  self_signed        boolean NOT NULL DEFAULT false,
  not_before         timestamptz NOT NULL,
  not_after          timestamptz NOT NULL,
  serial             text NOT NULL,
  key_algo           text NOT NULL,
  sig_algo           text NOT NULL,
  fingerprint        text NOT NULL,
  source             text NOT NULL DEFAULT 'upload' CHECK (source IN ('upload', 'acme', 'self')),
  certificate_pem    text NOT NULL,
  chain_pem          text,
  chain_names        text[] NOT NULL DEFAULT '{}',
  private_key_secret text NOT NULL,
  created_by         uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at         timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX panel_certificates_name_uq ON panel_certificates (lower(name));
CREATE UNIQUE INDEX panel_certificates_fingerprint_uq ON panel_certificates (fingerprint);

-- Tek satır: paneli ve posta sunucusunu koruyan sertifika. applied=false: sunucu ajanı henüz uygulamadı.
CREATE TABLE panel_ssl_settings (
  id                    boolean PRIMARY KEY DEFAULT true CHECK (id),
  active_certificate_id uuid REFERENCES panel_certificates (id) ON DELETE RESTRICT,
  applied               boolean NOT NULL DEFAULT false,
  updated_at            timestamptz NOT NULL DEFAULT now()
);
INSERT INTO panel_ssl_settings (id) VALUES (true);
