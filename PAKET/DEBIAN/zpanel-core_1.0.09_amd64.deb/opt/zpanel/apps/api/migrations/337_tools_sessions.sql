-- Panel session policy (Tools & Settings > Security > Session idle time). Single row (id = 1).
CREATE TABLE tools_session_settings (
  id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  idle_minutes integer NOT NULL DEFAULT 30 CHECK (idle_minutes BETWEEN 1 AND 1440),
  ip_lock      boolean NOT NULL DEFAULT false,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

INSERT INTO tools_session_settings (id) VALUES (1);
