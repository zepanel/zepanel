-- Zplus Webmail extension: "zplus" becomes a valid per-domain webmail client. The stored choice survives removing the
-- extension (the panel and the agent fall back to Roundcube while it is missing); no user data is touched.
ALTER TABLE mail_settings DROP CONSTRAINT IF EXISTS mail_settings_webmail_check;
ALTER TABLE mail_settings ADD CONSTRAINT mail_settings_webmail_check CHECK (webmail IN ('roundcube', 'snappymail', 'horde', 'zplus'));
