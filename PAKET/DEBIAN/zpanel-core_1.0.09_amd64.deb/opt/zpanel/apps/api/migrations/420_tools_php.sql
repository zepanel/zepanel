-- Server-wide PHP handlers (Tools & Settings > PHP): php.ini limits and extension switches per handler.
-- Handlers themselves come from the PHP catalog of the domain PHP tab (version x fpm|lsapi); a missing row means "defaults".
CREATE TABLE tools_php_handler (
  handler_id text PRIMARY KEY CHECK (char_length(handler_id) <= 32),
  memory     text NOT NULL CHECK (char_length(memory) <= 16),
  time       integer NOT NULL CHECK (time BETWEEN 0 AND 3600),
  upload     text NOT NULL CHECK (char_length(upload) <= 16),
  post       text NOT NULL CHECK (char_length(post) <= 16),
  extra      text NOT NULL DEFAULT '' CHECK (char_length(extra) <= 8000),
  ext        jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
