-- Fail2ban system pages (tools/security): global settings (one row) and the trusted IP list.
-- Banning and the log are the agent's job (503 agent_unavailable until it is connected), so nothing about bans is stored here.
CREATE TABLE fail2ban_system_settings (
  id         smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled    boolean NOT NULL DEFAULT true,
  bantime    integer NOT NULL DEFAULT 600 CHECK (bantime = -1 OR bantime BETWEEN 60 AND 31536000),
  findtime   integer NOT NULL DEFAULT 600 CHECK (findtime BETWEEN 10 AND 2592000),
  maxretry   integer NOT NULL DEFAULT 5 CHECK (maxretry BETWEEN 1 AND 100),
  mail       boolean NOT NULL DEFAULT false,
  mail_to    text NOT NULL DEFAULT '' CHECK (char_length(mail_to) <= 254),
  mail_ban   boolean NOT NULL DEFAULT true,
  mail_jail  boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO fail2ban_system_settings (id) VALUES (1);

-- addr is the canonical IPv4/IPv6 address or CIDR network (normalised by the application); kind: v4, v6, v4net, v6net.
CREATE TABLE fail2ban_trusted_ips (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  addr       text NOT NULL CHECK (char_length(addr) BETWEEN 1 AND 49),
  kind       text NOT NULL CHECK (kind IN ('v4', 'v6', 'v4net', 'v6net')),
  note       text NOT NULL DEFAULT '' CHECK (char_length(note) <= 120),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX fail2ban_trusted_ips_addr_uq ON fail2ban_trusted_ips (addr);
