-- Fail2ban jail rules (tools/security). The settings live in the panel; the agent applies them to the server.
CREATE TABLE fail2ban_jails (
  name        text PRIMARY KEY CHECK (name ~ '^[a-z0-9][a-z0-9_-]{0,39}$'),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 160),
  logpath     text NOT NULL CHECK (logpath ~ '^/[^[:space:]]*$' AND char_length(logpath) <= 255),
  port        text NOT NULL CHECK (char_length(port) BETWEEN 1 AND 120),
  maxretry    integer NOT NULL CHECK (maxretry BETWEEN 1 AND 100),
  findtime    integer NOT NULL CHECK (findtime BETWEEN 10 AND 2592000),
  bantime     integer NOT NULL CHECK (bantime = -1 OR bantime BETWEEN 60 AND 31536000),
  enabled     boolean NOT NULL DEFAULT true,
  sort_order  integer NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

INSERT INTO fail2ban_jails (name, description, logpath, port, maxretry, findtime, bantime, enabled, sort_order) VALUES
  ('recidive', 'Kısa sürede tekrar tekrar yasaklanan adresleri uzun süreli yasaklar.', '/var/log/fail2ban.log', 'tümü', 3, 86400, 604800, true, 1),
  ('sshd', 'SSH oturum açma denemelerinde başarısız kimlik doğrulamaları engeller.', '/var/log/auth.log', '22', 5, 600, 3600, true, 2),
  ('zpanel-login', 'zPanel yönetim paneline yapılan hatalı oturum açma girişimlerini engeller.', '/var/log/zpanel/panel.log', '8443', 3, 600, 1800, true, 3),
  ('postfix', 'SMTP üzerinden yapılan hatalı kimlik doğrulama ve kötüye kullanım denemelerini engeller.', '/var/log/mail.log', '25, 465, 587', 5, 600, 3600, true, 4),
  ('dovecot', 'POP3 ve IMAP posta erişiminde başarısız oturum açma girişimlerini engeller.', '/var/log/mail.log', '110, 143, 993, 995', 5, 600, 3600, false, 5);

-- Master switch of IP address banning (single row).
CREATE TABLE fail2ban_state (
  id         boolean PRIMARY KEY DEFAULT true CHECK (id),
  enabled    boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO fail2ban_state (id, enabled) VALUES (true, true);
