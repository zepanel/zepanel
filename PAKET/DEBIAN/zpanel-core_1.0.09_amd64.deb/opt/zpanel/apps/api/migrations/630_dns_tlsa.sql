-- DANE: SSL kurulumunda yazılan TLSA kayıtları için kayıt türü izni
ALTER TABLE domain_dns_records DROP CONSTRAINT IF EXISTS domain_dns_records_type_check;
ALTER TABLE domain_dns_records ADD CONSTRAINT domain_dns_records_type_check
  CHECK (type IN ('A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA', 'TLSA'));
