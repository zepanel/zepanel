-- E-posta sekmesi (S3): posta kutuları, yönlendirmeler, otomatik yanıtlayıcılar, takma adlar, posta listeleri,
-- catch-all/posta ayarları ve SPF/DKIM/DMARC durumu. Parolalar yalnızca Argon2id özeti olarak saklanır.

CREATE TABLE mail_accounts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id     uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  local_part    text NOT NULL,
  password_hash text NOT NULL,
  -- 0 = sınırsız; used_mb ajan tarafından güncellenir
  quota_mb      integer NOT NULL DEFAULT 1024 CHECK (quota_mb >= 0 AND quota_mb <= 102400),
  used_mb       integer NOT NULL DEFAULT 0 CHECK (used_mb >= 0),
  enabled       boolean NOT NULL DEFAULT true,
  last_login_at timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, local_part)
);

CREATE TABLE mail_forwards (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id   uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  source      text NOT NULL,
  destination text NOT NULL,
  keep_copy   boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, source, destination)
);

CREATE TABLE mail_responders (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES mail_accounts (id) ON DELETE CASCADE,
  subject    text NOT NULL,
  message    text NOT NULL,
  starts_on  date NOT NULL,
  ends_on    date NOT NULL,
  enabled    boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (account_id),
  CHECK (ends_on >= starts_on)
);

CREATE TABLE mail_aliases (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id         uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name              text NOT NULL,
  target_account_id uuid NOT NULL REFERENCES mail_accounts (id) ON DELETE CASCADE,
  created_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, name)
);

CREATE TABLE mail_lists (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name       text NOT NULL,
  members    text[] NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, name)
);

-- Alan adı başına tek satır; satır yoksa varsayılanlar geçerlidir.
CREATE TABLE mail_settings (
  domain_id          uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  catchall_mode      text NOT NULL DEFAULT 'reject' CHECK (catchall_mode IN ('reject', 'forward', 'discard')),
  catchall_account_id uuid REFERENCES mail_accounts (id) ON DELETE SET NULL,
  webmail            text NOT NULL DEFAULT 'roundcube' CHECK (webmail IN ('roundcube', 'snappymail', 'horde')),
  send_limit         integer NOT NULL DEFAULT 100 CHECK (send_limit BETWEEN 1 AND 500),
  spam_filter        boolean NOT NULL DEFAULT true,
  updated_at         timestamptz NOT NULL DEFAULT now()
);

-- SPF/DKIM/DMARC doğrulama sonucu ve DKIM genel anahtarı; değerleri ajan yazar.
CREATE TABLE mail_auth_status (
  domain_id   uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  spf         boolean NOT NULL DEFAULT false,
  dkim        boolean NOT NULL DEFAULT false,
  dmarc       boolean NOT NULL DEFAULT false,
  dkim_public text,
  server_ip   text,
  checked_at  timestamptz
);
