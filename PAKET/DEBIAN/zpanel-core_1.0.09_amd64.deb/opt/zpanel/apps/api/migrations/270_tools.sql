-- Tools and settings (Araçlar ve Ayarlar): server-wide settings pages and the lists behind them.
-- One row per settings page; the allowed keys, types and defaults live in src/modules/tools/schema.ts
-- and are enforced by the API, so the column only ever holds values that passed validation.
CREATE TABLE tools_settings (
  page       text PRIMARY KEY CHECK (page ~ '^[a-z0-9]+([.-][a-z0-9]+)*$' AND char_length(page) <= 60),
  data       jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
  updated_by uuid REFERENCES users (id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Records of the list pages (custom links, prohibited domains, ...). `collection` names the list.
-- Uniqueness inside a collection is checked by the API on a normalised key (see `unique` in schema.ts);
-- no lower() index on purpose: lower() is locale dependent in PostgreSQL (I becomes dotless i).
CREATE TABLE tools_items (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  collection text NOT NULL CHECK (collection ~ '^[a-z0-9]+([.-][a-z0-9]+)*$' AND char_length(collection) <= 60),
  data       jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tools_items_collection_idx ON tools_items (collection, created_at, id);
