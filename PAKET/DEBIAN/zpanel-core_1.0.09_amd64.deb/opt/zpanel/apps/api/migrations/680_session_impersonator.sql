-- "Hesaba gir" ile açılan oturumlarda girişi yapan yönetici/satıcı tutulur; "Yöneticiye dön" bu kayıtla geri geçiş yapar.
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS impersonator_id uuid REFERENCES users (id) ON DELETE CASCADE;
