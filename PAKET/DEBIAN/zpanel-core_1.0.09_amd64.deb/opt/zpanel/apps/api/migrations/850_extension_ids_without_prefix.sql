-- Uzantı kimliklerinden "ozel-" öneki kalkar (sahip kararı 2026-11-08): mağaza kimliği (öneksiz) tek kimliktir.
-- Eski göçler (690, 790, 810) olduğu gibi kalır; bu göç onların bıraktığı/yazdığı önekli kimlikleri öneksize çevirir.
-- Yalnız bilinen mağaza/yerleşik uzantılar çevrilir; kullanıcının yüklediği özel paketler (ext_custom, "ozel-" kuralı) olduğu gibi kalır.
-- Bir uzantının hem önekli hem öneksiz satırı varsa öneksiz satır kalır: etkin/menü bayrağı ikisinden biri açıksa açık,
-- sürüm büyük olan, kurulum tarihi eski olan korunur; önekli satır silinir. Göç tekrar çalışsa bir şey değiştirmez.

-- 1) Çift kayıt: öneksiz satıra ayarları birleştir.
UPDATE ext_installed t SET
  enabled      = t.enabled OR l.enabled,
  show_menu    = t.show_menu OR l.show_menu,
  version      = CASE WHEN string_to_array(l.version, '.')::int[] > string_to_array(t.version, '.')::int[] THEN l.version ELSE t.version END,
  installed_at = LEAST(t.installed_at, l.installed_at),
  updated_at   = GREATEST(t.updated_at, l.updated_at)
FROM ext_installed l
WHERE t.ext_id IN ('google-2fa', 'wordpress-toolkit', 'smarthost', 'zbackup', 'zsecurty')
  AND l.ext_id = 'ozel-' || t.ext_id;

-- 2) Çift kayıtta önekli satır silinir.
DELETE FROM ext_installed l
USING ext_installed t
WHERE t.ext_id IN ('google-2fa', 'wordpress-toolkit', 'smarthost', 'zbackup', 'zsecurty')
  AND l.ext_id = 'ozel-' || t.ext_id;

-- 3) Kalan önekli satırlar öneksize çevrilir.
UPDATE ext_installed SET ext_id = substr(ext_id, 6)
WHERE ext_id IN ('ozel-google-2fa', 'ozel-wordpress-toolkit', 'ozel-smarthost', 'ozel-zbackup', 'ozel-zsecurty');

-- 4) Geçmiş kayıtları (tekil anahtarı yok, satır silinmez).
UPDATE ext_history SET ext_id = substr(ext_id, 6)
WHERE ext_id IN ('ozel-google-2fa', 'ozel-wordpress-toolkit', 'ozel-smarthost', 'ozel-zbackup', 'ozel-zsecurty');
