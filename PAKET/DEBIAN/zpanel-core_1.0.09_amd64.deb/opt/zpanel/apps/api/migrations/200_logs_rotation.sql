-- Log rotation settings per domain (Logs tab). Log files themselves live on the server (agent).
CREATE TABLE logs_rotation (
  domain_id       uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  enabled         boolean NOT NULL DEFAULT true,
  frequency       text NOT NULL DEFAULT 'daily' CHECK (frequency IN ('daily', 'weekly', 'monthly')),
  keep            integer NOT NULL DEFAULT 14 CHECK (keep BETWEEN 1 AND 365),
  max_size_mb     integer NOT NULL DEFAULT 256 CHECK (max_size_mb BETWEEN 1 AND 10240),
  gzip            boolean NOT NULL DEFAULT true,
  reload_server   boolean NOT NULL DEFAULT true,
  last_rotated_at timestamptz,
  updated_at      timestamptz NOT NULL DEFAULT now()
);
