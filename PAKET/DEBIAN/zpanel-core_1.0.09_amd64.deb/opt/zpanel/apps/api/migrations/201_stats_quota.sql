-- Bandwidth quota alert settings per domain (Statistics tab). Traffic figures come from the agent.
CREATE TABLE stats_quota_settings (
  domain_id   uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  threshold   integer NOT NULL DEFAULT 80 CHECK (threshold IN (70, 80, 90)),
  notify_mail boolean NOT NULL DEFAULT true,
  updated_at  timestamptz NOT NULL DEFAULT now()
);
