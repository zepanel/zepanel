-- Toolkit sites (WordPress / Node.js / Laravel) bound to a domain. Settings live in jsonb;
-- environment variable values inside it are encrypted with src/secrets.ts. Running anything is the agent's job.
CREATE TABLE toolkit_sites (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  kind       text NOT NULL CHECK (kind IN ('wordpress', 'node', 'laravel')),
  enabled    boolean NOT NULL DEFAULT true,
  settings   jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (domain_id, kind)
);
CREATE INDEX toolkit_sites_kind_idx ON toolkit_sites (kind);
