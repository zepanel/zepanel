-- Profile and security state of a signed-in user. Name, e-mail, phone and company stay on users (004).
CREATE TABLE user_profiles (
  user_id             uuid PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
  title               text NOT NULL DEFAULT '',
  avatar_color        text NOT NULL DEFAULT '#0073ea' CHECK (avatar_color ~ '^#[0-9a-fA-F]{6}$'),
  avatar_shape        text NOT NULL DEFAULT 'round' CHECK (avatar_shape IN ('round', 'square')),
  avatar_letters      smallint NOT NULL DEFAULT 2 CHECK (avatar_letters IN (1, 2)),
  lang                text NOT NULL DEFAULT 'tr' CHECK (lang IN ('tr', 'en', 'de')),
  tz                  text NOT NULL DEFAULT 'Europe/Istanbul',
  digest              text NOT NULL DEFAULT 'instant' CHECK (digest IN ('instant', 'daily', 'weekly')),
  notify              jsonb NOT NULL DEFAULT '{}'::jsonb,
  prefs               jsonb NOT NULL DEFAULT '{}'::jsonb,
  email_verified_at   timestamptz,
  email_verified_for  text NOT NULL DEFAULT '',
  email_code_hash     bytea,
  email_code_expires  timestamptz,
  email_code_tries    smallint NOT NULL DEFAULT 0,
  password_changed_at timestamptz,
  two_factor_secret   text,
  two_factor_pending  text,
  two_factor_at       timestamptz,
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- One-time recovery codes: only a hash is kept, shown once when created.
CREATE TABLE user_recovery_codes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  code_hash  bytea NOT NULL,
  used_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX user_recovery_codes_user_idx ON user_recovery_codes (user_id);

-- Application passwords (mail clients, file transfer tools, automation): Argon2id hashes, shown once.
CREATE TABLE user_app_passwords (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  label        text NOT NULL,
  kind         text NOT NULL CHECK (kind IN ('mail', 'transfer', 'automation', 'other')),
  secret_hash  text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz
);
CREATE INDEX user_app_passwords_user_idx ON user_app_passwords (user_id, created_at DESC);
