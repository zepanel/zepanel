-- Satıcı oluşturulunca varsayılan olarak açılan sınırsız satıcı paketi
INSERT INTO reseller_plans (id, name, description, limits, perms, sort_order) VALUES
  ('sinirsiz', 'Sınırsız Satıcı Paketi', 'Tüm kaynaklar ve yetkiler sınırsız (varsayılan paket)',
   '{"disk":-1,"traffic":-1,"customers":-1,"domains":-1,"mail":-1,"db":-1}', '{customers,plans,dns,ssh,ssl,backup,wp,suspend}', 0)
ON CONFLICT (id) DO NOTHING;
