-- Server firewall (tools/security/firewall): ordered rule list and the master switch / default policy.
-- The rules are evaluated top to bottom (position); applying them to the server belongs to the agent (phase 3).
CREATE TABLE firewall_settings (
  id          smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled     boolean NOT NULL DEFAULT false,
  default_in  text NOT NULL DEFAULT 'deny' CHECK (default_in IN ('allow', 'deny')),
  default_out text NOT NULL DEFAULT 'allow' CHECK (default_out IN ('allow', 'deny')),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
INSERT INTO firewall_settings (id) VALUES (1);

CREATE TABLE firewall_rules (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  position   integer NOT NULL,
  name       text NOT NULL CHECK (char_length(name) BETWEEN 3 AND 60),
  note       text NOT NULL DEFAULT '' CHECK (char_length(note) <= 120),
  direction  text NOT NULL CHECK (direction IN ('in', 'out')),
  proto      text NOT NULL CHECK (proto IN ('tcp', 'udp', 'tcp-udp')),
  ports      text NOT NULL CHECK (char_length(ports) BETWEEN 1 AND 200),
  src        text NOT NULL CHECK (char_length(src) BETWEEN 2 AND 49),
  action     text NOT NULL CHECK (action IN ('allow', 'deny')),
  enabled    boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- Same case folding as migration 007: the "C" collation does not depend on the database locale.
CREATE UNIQUE INDEX firewall_rules_name_uq ON firewall_rules (lower(name COLLATE "C"));
CREATE INDEX firewall_rules_position_ix ON firewall_rules (position);
