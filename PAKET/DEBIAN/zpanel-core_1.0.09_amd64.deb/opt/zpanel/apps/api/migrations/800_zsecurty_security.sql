-- zSecurty AI traffic ban engine. The Go daemon (uzantilar/zsecurty) never touches Postgres directly:
-- it reports through the zsecurty-security module's api-key-authenticated endpoints, which own every
-- write below. Banning decisions (shadow mode, leaky-bucket score/signals, progressive penalty) are
-- computed by the daemon; this schema is the durable, race-safe record of what was decided and applied.

-- Single-row policy. shadow_mode defaults to true: a real ban only starts once an administrator turns
-- it off deliberately from the panel.
CREATE TABLE zsecurty_security_config (
  id                               smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  shadow_mode                      boolean NOT NULL DEFAULT true,
  score_ban_threshold              integer NOT NULL DEFAULT 75 CHECK (score_ban_threshold BETWEEN 1 AND 1000),
  score_suspicious_threshold       integer NOT NULL DEFAULT 40 CHECK (score_suspicious_threshold BETWEEN 1 AND 1000),
  min_signal_categories            integer NOT NULL DEFAULT 2 CHECK (min_signal_categories >= 1),
  ban_duration_seconds             integer NOT NULL DEFAULT 21600 CHECK (ban_duration_seconds BETWEEN 60 AND 2592000),
  -- Aşamalı ceza: 1. ban, 2. ban, 3. ban... süresi (saniye); dizi biterse son değer tekrar kullanılır.
  ban_duration_escalation_seconds  integer[] NOT NULL DEFAULT ARRAY[7200, 43200, 259200],
  -- Bu kadarıncı tekrardan sonra (tüm zamanların ban sayısı) IP kalıcı kara listeye düşer.
  permanent_ban_after_count        integer NOT NULL DEFAULT 5 CHECK (permanent_ban_after_count BETWEEN 2 AND 50),
  weights                          jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at                       timestamptz NOT NULL DEFAULT now()
);
INSERT INTO zsecurty_security_config (id) VALUES (1);

-- Administrator-defined custom IP/CIDR allow list, checked before the known search-engine ranges even
-- reach scoring (the daemon's own whitelist package also carries the static Googlebot/Bingbot ranges;
-- these rows are the extra, site-specific entries).
CREATE TABLE zsecurty_whitelist (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  addr       text NOT NULL CHECK (char_length(addr) BETWEEN 1 AND 49),
  note       text NOT NULL DEFAULT '' CHECK (char_length(note) <= 160),
  created_by uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX zsecurty_whitelist_addr_uq ON zsecurty_whitelist (addr);

-- Append-only AI scoring log: every evaluation the daemon makes, whether or not it crosses the ban
-- threshold (so the panel can show "would have banned" activity while shadow mode is on).
CREATE TABLE zsecurty_detections (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip         text NOT NULL CHECK (char_length(ip) BETWEEN 3 AND 49),
  score      integer NOT NULL,
  signals    jsonb NOT NULL DEFAULT '[]'::jsonb,
  reasons    jsonb NOT NULL DEFAULT '[]'::jsonb,
  action     text NOT NULL CHECK (action IN ('allow', 'suspicious', 'ban')),
  shadow     boolean NOT NULL,
  vpn        boolean NOT NULL DEFAULT false,
  datacenter boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX zsecurty_detections_ip_idx ON zsecurty_detections (ip, created_at DESC);

-- Every ban ever issued. History is never deleted (occurrence/progressive-penalty and "kalıcı kara
-- liste" counting read the full history); removed_at marks a row no longer in effect, whether it
-- expired naturally or was removed by an administrator (removed_by is set only for the latter).
-- permanent = (expires_at IS NULL): no automatic expiry, cleared only by a manual removal.
CREATE TABLE zsecurty_bans (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip          text NOT NULL CHECK (char_length(ip) BETWEEN 3 AND 49),
  reason      text NOT NULL DEFAULT '' CHECK (char_length(reason) <= 500),
  signals     jsonb NOT NULL DEFAULT '[]'::jsonb,
  score       integer NOT NULL DEFAULT 0,
  occurrence  integer NOT NULL DEFAULT 1 CHECK (occurrence >= 1),
  permanent   boolean NOT NULL DEFAULT false,
  shadow      boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz,
  removed_at  timestamptz,
  removed_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  CHECK (permanent = (expires_at IS NULL))
);
CREATE INDEX zsecurty_bans_ip_idx ON zsecurty_bans (ip, created_at DESC);
-- At most one still-in-effect ban per IP; expireStale() (zsecurty-security module) clears removed_at
-- for naturally-expired rows before any new insert, so this never blocks a legitimate re-ban.
CREATE UNIQUE INDEX zsecurty_bans_active_ip_uq ON zsecurty_bans (ip) WHERE removed_at IS NULL;
