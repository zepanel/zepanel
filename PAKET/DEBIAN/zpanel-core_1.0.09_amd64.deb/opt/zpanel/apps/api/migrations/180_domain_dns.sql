-- DNS zone of a primary domain: SOA values, DNSSEC state and the records.
-- A zone row is created on first use together with the default record template.
CREATE TABLE domain_dns_zones (
  domain_id         uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  soa_ns            text NOT NULL,
  soa_mail          text NOT NULL,
  serial            bigint NOT NULL,
  refresh_s         integer NOT NULL,
  retry_s           integer NOT NULL,
  expire_s          integer NOT NULL,
  minimum_s         integer NOT NULL,
  dnssec_enabled    boolean NOT NULL DEFAULT false,
  dnssec_tag        integer,
  dnssec_digest     text,
  dnssec_created_at timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE domain_dns_records (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq        bigint GENERATED ALWAYS AS IDENTITY,
  domain_id  uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  name       text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 253),
  type       text NOT NULL CHECK (type IN ('A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA')),
  value      text NOT NULL CHECK (char_length(value) BETWEEN 1 AND 4096),
  ttl        integer NOT NULL CHECK (ttl BETWEEN 60 AND 604800),
  prio       integer CHECK (prio BETWEEN 0 AND 65535),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX domain_dns_records_domain_idx ON domain_dns_records (domain_id, seq);
