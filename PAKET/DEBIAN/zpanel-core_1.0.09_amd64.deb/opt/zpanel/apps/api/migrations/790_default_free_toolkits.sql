-- Ücretsiz toolkit'ler (Docker, SSH Terminal, Yedekleme, Git, SSL, İzleme, Onarım, Taşıma) panelle birlikte varsayılan yüklü gelir.
-- Yönetici isterse kaldırır; göç yalnız bir kez çalıştığı için kaldırılan uzantı kendiliğinden geri gelmez.
INSERT INTO ext_installed (ext_id, version) VALUES
  ('docker-toolkit', '1.0.1'),
  ('ssh-terminal', '1.0.1'),
  ('backup-toolkit', '1.0.1'),
  ('git-toolkit', '1.0.1'),
  ('ssl-toolkit', '1.0.1'),
  ('monitoring-toolkit', '1.0.1'),
  ('repair-toolkit', '1.0.1'),
  ('migration-toolkit', '1.0.1')
ON CONFLICT (ext_id) DO NOTHING;
