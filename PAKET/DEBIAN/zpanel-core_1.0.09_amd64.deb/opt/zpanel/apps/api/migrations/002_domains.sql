CREATE TABLE domains (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  owner_id   uuid NOT NULL REFERENCES users (id),
  status     text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);

-- one live record per name; soft-deleted names can be registered again
CREATE UNIQUE INDEX domains_name_live_uq ON domains (name) WHERE deleted_at IS NULL;
CREATE INDEX domains_owner_idx ON domains (owner_id) WHERE deleted_at IS NULL;
CREATE INDEX domains_status_idx ON domains (status) WHERE deleted_at IS NULL;
