-- 690 ve 790 numaralı göçler, WordPress/Node/Laravel/Docker/SSH/Yedekleme/Git/SSL/İzleme/Onarım/Taşıma araç setlerini
-- "kurulu" olarak ekledi; `enabled` belirtilmediği için sütun varsayılanı (true) uygulandı, yani hepsi otomatik AÇIK geldi.
-- Kural: bu araç setleri ilk kurulumda kurulu/etkin gelmez, yönetici Uzantılar sayfasından kendisi kurar.
-- Satırlar silinir (kaldırma deseniyle aynı): göç yalnız bir kez çalışır, yönetici dilediğinde Uzantılar sayfasından tekrar kurabilir.
DELETE FROM ext_installed WHERE ext_id IN (
  'ozel-wordpress-toolkit', 'wordpress-toolkit', 'node-toolkit', 'laravel-toolkit',
  'docker-toolkit', 'ssh-terminal', 'backup-toolkit', 'git-toolkit',
  'ssl-toolkit', 'monitoring-toolkit', 'repair-toolkit', 'migration-toolkit'
);
