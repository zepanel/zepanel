-- Gerçek TLS durumu: periyodik denetim (agent sites.auditTls + 127.0.0.1:443 SNI sondası) sonucu. tls_problem boş değilse panel
-- "sertifika geçerli/uygulandı" DEMEZ ve nedeni gösterir; tls_checked_at son denetim zamanıdır.
ALTER TABLE ssl_domain_settings ADD COLUMN IF NOT EXISTS tls_problem text;
ALTER TABLE ssl_domain_settings ADD COLUMN IF NOT EXISTS tls_checked_at timestamptz;
