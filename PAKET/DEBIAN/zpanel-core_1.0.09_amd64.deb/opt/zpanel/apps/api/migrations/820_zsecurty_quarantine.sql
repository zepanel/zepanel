-- zSecurty file quarantine ledger. The file itself is never moved: it stays at file_path and is locked
-- down in place (chown root:root + chmod 0600 via the root agent's zsecurty.quarantineLock RPC, see
-- servis/api/src/modules/zsecurty/agent.ts) so the domain's own tenant/webserver account can no longer
-- read or execute it. This table is the durable record the "Karantina" tab lists from (never a
-- filesystem scan) and the only place original_uid/original_gid/original_mode are kept, so a later
-- "Temizle"/restore can give the file back to its real owner with zsecurty.quarantineRelease.
CREATE TABLE zsecurty_quarantine (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_path             text NOT NULL CHECK (char_length(file_path) BETWEEN 1 AND 1000),
  -- NULL when the path did not resolve to a known domain home (rare; lock then cannot be attempted).
  domain                text CHECK (domain IS NULL OR char_length(domain) BETWEEN 1 AND 253),
  threat_name           text NOT NULL DEFAULT '' CHECK (char_length(threat_name) <= 300),
  threat_type           text NOT NULL DEFAULT '' CHECK (char_length(threat_type) <= 100),
  severity              text NOT NULL DEFAULT 'medium' CHECK (severity IN ('critical', 'high', 'medium')),
  source                text NOT NULL DEFAULT '' CHECK (char_length(source) <= 100),
  -- Every engine that flagged the file (hash/YARA/ClamAV/anomaly) - see runScanWorker's `engines`.
  engines               jsonb NOT NULL DEFAULT '[]'::jsonb,
  ai_is_false_positive  boolean,
  ai_confidence         numeric(3, 2) CHECK (ai_confidence IS NULL OR (ai_confidence BETWEEN 0 AND 1)),
  ai_reason             text NOT NULL DEFAULT '' CHECK (char_length(ai_reason) <= 1000),
  -- "Manuel (admin)" or "AI: <ai_reason>" - who/what decided to quarantine this file.
  reason                text NOT NULL DEFAULT '' CHECK (char_length(reason) <= 500),
  original_uid          integer NOT NULL,
  original_gid          integer NOT NULL,
  -- "0644"-style octal string, as the agent's modeString() formats it.
  original_mode         text NOT NULL CHECK (char_length(original_mode) BETWEEN 2 AND 8),
  status                text NOT NULL DEFAULT 'quarantined' CHECK (status IN ('quarantined', 'restored', 'deleted')),
  quarantined_at        timestamptz NOT NULL DEFAULT now(),
  restored_at           timestamptz,
  deleted_at            timestamptz
);
CREATE INDEX zsecurty_quarantine_status_idx ON zsecurty_quarantine (status, quarantined_at DESC);
-- At most one active (still locked) quarantine row per file path.
CREATE UNIQUE INDEX zsecurty_quarantine_active_path_uq ON zsecurty_quarantine (file_path) WHERE status = 'quarantined';
