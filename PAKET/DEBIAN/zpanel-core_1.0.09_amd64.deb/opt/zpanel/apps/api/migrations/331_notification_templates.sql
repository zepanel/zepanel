-- Event notifications of the panel (Tools & Settings > Notifications): recipient groups, one extra address and an
-- optional customised template per event. A missing row means "defaults"; subject/message NULL means the default text.
CREATE TABLE notification_templates (
  event_id    text PRIMARY KEY CHECK (event_id IN ('disk', 'traffic', 'ssl', 'update', 'fail2ban', 'expiry')),
  to_admin    boolean NOT NULL DEFAULT false,
  to_customer boolean NOT NULL DEFAULT false,
  to_reseller boolean NOT NULL DEFAULT false,
  extra_email text NOT NULL DEFAULT '' CHECK (char_length(extra_email) <= 160),
  subject     text CHECK (subject IS NULL OR char_length(subject) BETWEEN 1 AND 150),
  message     text CHECK (message IS NULL OR char_length(message) BETWEEN 1 AND 2000),
  updated_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  updated_at  timestamptz NOT NULL DEFAULT now()
);
