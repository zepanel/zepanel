-- Per-domain PHP configuration (runtime, FPM pool, php.ini overrides, extensions).
-- A missing row means "defaults"; the row is created on the first save.
CREATE TABLE domain_php (
  domain_id       uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  enabled         boolean NOT NULL DEFAULT true,
  version         text NOT NULL,
  handler         text NOT NULL,
  run_user        text NOT NULL,
  pm              jsonb NOT NULL,
  ini             jsonb NOT NULL DEFAULT '{}'::jsonb,
  extra           text NOT NULL DEFAULT '',
  ext             jsonb NOT NULL DEFAULT '{}'::jsonb,
  pending         boolean NOT NULL DEFAULT true,
  applied_version text,
  applied_handler text,
  applied_at      timestamptz,
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE domain_php_history (
  id        bigserial PRIMARY KEY,
  domain_id uuid NOT NULL REFERENCES domains (id) ON DELETE CASCADE,
  at        timestamptz NOT NULL DEFAULT now(),
  event     text NOT NULL,
  params    jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX domain_php_history_domain_idx ON domain_php_history (domain_id, at DESC);
