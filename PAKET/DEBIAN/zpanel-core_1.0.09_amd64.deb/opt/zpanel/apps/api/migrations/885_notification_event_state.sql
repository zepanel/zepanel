-- Bildirim şablonlu olayların (disk, traffic, ssl, fail2ban, expiry) yinelenmemesi için son bildirilen imza.
-- Aynı (olay, konu) için imza değişmedikçe yeniden bildirim gönderilmez; durum bitince satır silinir.
CREATE TABLE notification_event_state (
  event_id    text NOT NULL CHECK (event_id IN ('disk', 'traffic', 'ssl', 'update', 'fail2ban', 'expiry')),
  subject     text NOT NULL CHECK (char_length(subject) BETWEEN 1 AND 300),
  signature   text NOT NULL CHECK (char_length(signature) <= 300),
  notified_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (event_id, subject)
);
