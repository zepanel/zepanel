-- Abonelik = bir ana alan adının servis planı ve bitiş tarihi. Satırı olmayan alan adı "plansız abonelik" sayılır.
CREATE TABLE subscriptions (
  domain_id  uuid PRIMARY KEY REFERENCES domains (id) ON DELETE CASCADE,
  plan_id    text NOT NULL REFERENCES service_plans (id) ON DELETE RESTRICT,
  expires_on date NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subscriptions_plan_idx ON subscriptions (plan_id);
