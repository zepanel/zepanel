-- Plan limitleri (P28): bir aboneliğin kapsadığı tüm alan adları (kendi alan adı + bağlı ek alan adları).
-- Sayım bu görünüm üzerinden yapılır; kaynak tabloları (mail_accounts, domain_databases, ftp_accounts) değişmez.
CREATE VIEW subscription_domain_map AS
  SELECT s.domain_id AS subscription_id, s.domain_id AS domain_id FROM subscriptions s
  UNION ALL
  SELECT ds.subscription_id, ds.domain_id FROM domain_subscriptions ds;
