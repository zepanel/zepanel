-- Otomatik çalıştırma durumu (worker): zamanlanmış görev bir dakikada en fazla bir kez çalışsın (çift çalıştırma yok),
-- işletim sistemi güncelleme bildirimi aynı bekleyen paket kümesi için tekrarlanmasın.
ALTER TABLE scheduler_tasks ADD COLUMN last_scheduled_at timestamptz;
ALTER TABLE tools_os_update_settings ADD COLUMN last_notified_sig text NOT NULL DEFAULT '' CHECK (char_length(last_notified_sig) <= 64);
