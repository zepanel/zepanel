-- IP havuzu: arayüz adı eth0/eth1 ile sınırlı değildir (AlmaLinux 8'de ens160 gibi adlar gelir). Linux arayüz adı en çok 15 karakter.
ALTER TABLE ip_addresses DROP CONSTRAINT IF EXISTS ip_addresses_iface_check;
ALTER TABLE ip_addresses ADD CONSTRAINT ip_addresses_iface_check CHECK (iface ~ '^[A-Za-z0-9][A-Za-z0-9_.:@-]{0,14}$');
