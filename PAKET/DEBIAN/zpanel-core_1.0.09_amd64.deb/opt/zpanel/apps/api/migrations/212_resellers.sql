-- Satıcılar: kullanıcı satırı (role = 'reseller') + satıcıya özel profil. Satıcı planları ayrı bir şablon tablosudur.
-- Sınır -1 = sınırsız.
CREATE TABLE reseller_plans (
  id          text PRIMARY KEY CHECK (id ~ '^[a-z0-9]+$'),
  name        text NOT NULL,
  description text NOT NULL DEFAULT '',
  limits      jsonb NOT NULL,
  perms       text[] NOT NULL DEFAULT '{}',
  sort_order  integer NOT NULL
);

INSERT INTO reseller_plans (id, name, description, limits, perms, sort_order) VALUES
  ('bronze',   'Reseller Bronze Başlangıç',  'Küçük ajanslar için giriş paketi',
   '{"disk":100,"traffic":1000,"customers":15,"domains":30,"mail":300,"db":60}', '{customers,dns,ssl}', 1),
  ('silver',   'Reseller Silver Pro',        'Büyüyen bayiler için dengeli paket',
   '{"disk":500,"traffic":5000,"customers":50,"domains":100,"mail":1000,"db":200}', '{customers,plans,dns,ssl,backup}', 2),
  ('gold',     'Reseller Gold Unlimited',    'Geniş kaynaklı, çoğu sınırı kaldırılmış paket',
   '{"disk":1000,"traffic":-1,"customers":100,"domains":-1,"mail":-1,"db":-1}', '{customers,plans,dns,ssh,ssl,backup,wp}', 3),
  ('platinum', 'Reseller Platinum Kurumsal', 'Kurumsal bayiler için tüm yetkiler',
   '{"disk":-1,"traffic":-1,"customers":-1,"domains":-1,"mail":-1,"db":-1}', '{customers,plans,dns,ssh,ssl,backup,wp,suspend}', 4);

CREATE TABLE reseller_profiles (
  user_id    uuid PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
  kind       text NOT NULL DEFAULT 'Gümüş Bayi',
  contact    text NOT NULL DEFAULT '',
  city       text NOT NULL DEFAULT '',
  note       text NOT NULL DEFAULT '',
  plan_id    text NOT NULL DEFAULT 'silver' REFERENCES reseller_plans (id),
  ownership  text NOT NULL DEFAULT 'dedicated' CHECK (ownership IN ('dedicated', 'shared')),
  limits     jsonb NOT NULL,
  perms      text[] NOT NULL DEFAULT '{}',
  brand      jsonb NOT NULL DEFAULT '{}'::jsonb,
  verify     jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
